<!DOCTYPE html>
<html>
<head>
  <title>Halaman Tidak Ditemukan - <?php echo namaSitus();?></title>
  <meta name="robots" content="noindex">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--Import Google Icon Font-->
  <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
  <style>
  .error-template {padding: 40px 15px;text-align: center;}
  .error-actions {margin-top:15px;margin-bottom:15px;}
  .error-actions .btn { margin-right:10px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="error-template">
          <h1>Oops!</h1>
            <h2>
              404 Not Found</h2>
              <div class="error-details">
                Sorry, an error has occured, Requested page not found!
              </div>
              <a href="<?php echo base_url();?>"<button type="button" class="btn btn-primary">Back To Home</button></a>
            </div>
          </div>
        </div>
      </div>

    </body>
    </html>
