<!DOCTYPE html>
<html lang="id-ID">
<head>
  <title><?php echo $title;?></title>
  <!-- Meta -->
  <meta name="robots" content="noindex">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="theme-color" content="#0055D9">
  <meta name="msapplication-navbutton-color" content="#4287f5">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="#4287f5">
  <link rel="apple-touch-icon" sizes="180x180" href="./assets/gambar/favicon.ico">
  <link rel="icon" type="image/png" href="./assets/gambar/favicon.ico">
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="error-template">
          <h1>
            Oops!</h1>
            <h2>
              404 Not Found</h2>
              <div class="error-details">
                Sorry, an error has occured, Requested page not found!
              </div>
              <div class="error-actions">
                <a href="http://www.jquery2dotnet.com" class="btn btn-primary btn-lg"><span class="glyphicon glyphicon-home"></span>
                  Take Me Home </a><a href="http://www.jquery2dotnet.com" class="btn btn-default btn-lg"><span class="glyphicon glyphicon-envelope"></span> Contact Support </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </body>
      </html>
