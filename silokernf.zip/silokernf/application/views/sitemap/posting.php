<?php echo'<?xml version="1.0" encoding="UTF-8" ?>' ?>

<urlset  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd http://www.google.com/schemas/sitemap-image/1.1 http://www.google.com/schemas/sitemap-image/1.1/sitemap-image.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">

<!-- Your Sitemap -->
 <?php foreach($sitemap as $look) { ?>
 <url>
 <loc><?php echo base_url();?><?php echo $look->slug;?>/<?php echo $look->id_artikel;?></loc>
 <changefreq>always</changefreq>
 <priority>1.0</priority>
 <?php
  if ($look->tanggal_update == 0000-00-00) {?>
    <lastmod><?php echo $look->tanggal_posting;?></lastmod>
  <?php } else {?>
    <lastmod><?php echo $look->tanggal_update;?></lastmod>
  <?php } ?>
 <image:image>
			<image:loc><?php echo base_url();?>assets/gambar/perusahaan/<?php echo $look->gambar;?></image:loc>
			<image:caption><![CDATA[<?php echo $look->judul_seo;?>]]></image:caption>
	</image:image>
 </url>
 <?php } ?>

</urlset>
