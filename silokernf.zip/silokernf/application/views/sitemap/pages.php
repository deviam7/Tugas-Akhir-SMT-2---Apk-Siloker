<?php echo'<?xml version="1.0" encoding="UTF-8" ?>' ?>

<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <?php foreach ($page as $look) {?>
    <url>
      <loc><?php echo base_url();?>page/<?php echo str_replace(" ","-",strtolower($look->judul_page));?></loc>
      <lastmod><?php echo $look->tanggal;?></lastmod>
      <changefreq>always</changefreq>
      <priority>1.0</priority>
    </url>
  <?php } ?>
</urlset>
