<div class="container" style="margin-top:1rem;">
  <div class="row">
    <?php foreach ($job as $look) {?>
      <div class="col-lg-7 col-xs-12">
        <div class="card">
          <div class="card-body">
            <div class="row">
              <div class="col-md-10 col-sm-12">
                <h1 class="card-title" style="font-size:1.5em"><strong><?php echo $look->judul_pekerjaan;?></strong></h1></hr>
              </div>
              <div class="logo-perusahaan col-md-2">
                <a href="#" title="Lowongan Kerja di <?php echo $look->nama_perusahaan;?>"><img src="<?php echo base_url();?>assets/gambar/perusahaan/<?php echo $look->gambar;?>" alt="<?php echo $look->judul_seo;?>"></a>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <span class="meta-job" style="font-size:1.2em;line-height:1.5">Gaji</strong> :
                  Rp. <?php echo number_format($look->gaji_min,0,',','.');?>
                  <?php if ($look->gaji_max == 0) {
                    echo "";
                  }else {
                    echo "- ".number_format($look->gaji_max,0,',','.');
                  }
                  ?>
                </span><br>
                <span class="meta-job" style="font-size:1.1em;line-height:1.5;color:#3f94cc;"><?php echo $look->nama_perusahaan;?></span><br>
                <span class="meta-job" style="font-size:1.1em;line-height:1.5;"><?php echo $look->street;?>, <?php $kabupaten = strtolower($look->name); echo ucwords($kabupaten)?>, <?php $provinsi = strtolower($look->name_provinces); echo ucwords($provinsi);?> <?php echo $look->kode_pos;?></span><br>
                <span class="meta-job" style="font-size:1.1em;line-height:1.5;color:#5e6163">Diterbitkan : <?php echo $look->tanggal_posting;?></span>
              </div>
            </div>
          </div>
        </div>
        <div style="margin-top:1rem">
          <?php
          if (kodeUrlAdsense() == null) {
            echo "";
          }else {
            echo kodeUrlAdsense();
          }
          ?>
        </div>
        <div class="card" style="margin-top:1rem;">
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <h2 class="card-title" style="font-size:1.2em"><strong>Deskripsi Pekerjaan</strong></h2><hr>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <?php echo $look->deskripsi_pekerjaan;?>
              </div>
            </div>
          </div>
        </div>
        <div style="margin-top:1rem">
          <?php
          if (kodeTengahAdsense() == null) {
            echo "";
          }else {
            echo kodeTengahAdsense();
          }
          ?>
        </div>
        <div class="card" style="margin-top:1rem;">
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <h2 class="card-title" style="font-size:1.2em"><strong>Perusahaan Perekrut</strong></h2><hr>
              </div>
            </div>
            <div class="row">
              <div class="col-md-9 col-xs-12">
                <span class="meta-job" style="font-size:1em"><strong><?php echo $look->nama_perusahaan;?></strong></span><br>
                <span class="meta-job" style="font-size:1em">Kuantitas Pekerja: <?php echo $look->kuantitas_pekerja;?> Orang</span>
              </div>
              <div class="logo-perusahaan col-md-3">
                <a title="Lowongan Kerja di <?php echo $look->nama_perusahaan;?>"><img src="<?php echo base_url();?>assets/gambar/perusahaan/<?php echo $look->gambar;?>" alt="<?php echo $look->judul_seo;?>"></a>
              </div>
            </div>
            <div class="row" style="margin-top:1rem">
              <div class="col-md-12">
                <p><?php echo $look->deskripsi_perusahaan;?></p>
              </div>
            </div>
          </div>
        </div>
        <div class="card" style="margin-bottom:1rem; margin-top:1rem;">
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <?php
                if ($look->email_lamar == null) {
                  echo "";
                }else {?>
                  <a href="mailto:<?php echo $look->email_lamar;?>">
                      
                      <button type="button" class="btn btn-primary" id="lamarEmail">
  <span class="badge badge-light"><i class="fa fa-envelope text-primary"></i></span> Lamar Via Email</button></a>
                
                <?php }
                if ($look->link_lamar == null) {
                  echo "";
                }else {?>
                  <a href="<?php echo $look->link_lamar;?>" target="_blank" rel="nofollow"><button type="button" class="btn btn-danger" id="lamarWebsite"><span class="badge badge-light"><i class="fa fa-globe text-danger"></i></span> Lamar Via Website</button></a>
                <?php } ?>

            <div class="text-muted" style="float:right; margin-left: auto!important;" id="share"> Bagikan :
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo current_url();?>" target="_blank"><button class="btn btn-facebook" type="button" role="button"><i class="fa fa-facebook"></i></button></a>
                <a href="https://twitter.com/share?url=<?php echo current_url();?>&text=<?php echo $look->judul_seo;?>" target="_blank"><button class="btn btn-twitter" type="button" role="button"><i class="fa fa-twitter"></i></button></a>
                <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo current_url();?>&title=<?php echo $look->judul_seo;?>" target="_blank"><button class="btn btn-linkedin" type="button" role="button"><i class="fa fa-linkedin"></i></button></a>
                <a href="whatsapp://send?text=<?php echo $look->judul_seo;?> cek di >> <?php echo current_url();?>" target="_blank"><button class="btn btn-whatsapp" type="button" role="button"><i class="fa fa-whatsapp"></i></button></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    <?php } ?>
    <div class="col-lg-4 col-xs-12 id="randomPekerjaan">
      <div class="card">
        <div class="card-body">
          <div class="row">
            <div class="col-md-12 col-sm-12">
              <h2 class="card-title" style="font-size:1.4em">Lowongan Terkait</h2><hr>
              <?php
              foreach ($lowonganTerkait->result() as $look) {?>
                <div class="card-job row">
                  <div class="col-md-8 col-xs-12">
                    <div class="new-time">
                      <h2 class="job-title"><a title="<?php echo $look->judul_pekerjaan;?>" href="<?php echo base_url();?><?php echo $look->slug;?>/<?php echo $look->id_artikel;?>"><span><?php echo $look->judul_pekerjaan;?></span></a></h2><br>
                      <span class="meta-job" style="font-size:13px;"> <i class="fa fa fa-clock-o" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $look->tanggal_posting;?></span><br>
                      <span class="meta-job" style="font-size:13px;"> <i class="	fa fa-dollar" aria-hidden="true"></i> &nbsp;&nbsp;Rp. <?php echo number_format($look->gaji_min,0,',','.');?>
                    <?php if ($look->gaji_max == 0) {
                    echo "";
                  }else {
                    echo "- ".number_format($look->gaji_max,0,',','.');
                  }
                  ?>
                  </span><br>
                      <span class="meta-job" style="font-size:13px"><strong> <i class="fa fa-building-o" aria-hidden="true"></i> &nbsp;<?php echo $look->nama_perusahaan;?></strong></span> <br>
                      <span class="meta-job" style="font-size:13px"> <i class="fa fa fa-map-marker" aria-hidden="true"></i></span><span class="meta-job">&nbsp;&nbsp;<?php $kabupaten = explode(" ",$look->name); echo $kabupaten[1];?></span><br>
                    </div>
                  </div>
                  <div class="logo-perusahaan col-md-4">
                    <a href="<?php echo base_url();?><?php echo $look->slug;?>/<?php echo $look->id_artikel;?>" title="Lowongan Kerja di <?php echo $look->nama_perusahaan;?>"><img src="<?php echo base_url();?>assets/gambar/perusahaan/<?php echo $look->gambar;?>" alt="<?php echo $look->judul_seo;?>"></a>
                  </div>
                </div>
              <?php }?>
            </div>
          </div>
        </div>
      </div>
      <div style="margin-top:1rem">
        <!-- Kode Adsense -->
        <?php
        if (kodeSidebarAdsense() == null) {
          echo "";
        }else {
          echo kodeSidebarAdsense();
        }
        ?>
      </div>
    </div>
  </div>
</div>
