<div class="container" style="margin-top:1rem;">
  <div class="row">
    <div class="col-md-11">
      <?php foreach ($page as $look) {?>
      <div class="card">
        <div class="card-body">
          <h1 class="card-title" style="font-size:1.5em"><?php echo $look->judul_page;?></h1><hr>
          <div class="col-md-8">
            <?php echo $look->isi_page;?>
          </div>
        </div>
      </div>
      <?php } ?>
    </div>
  </div>
</div>
