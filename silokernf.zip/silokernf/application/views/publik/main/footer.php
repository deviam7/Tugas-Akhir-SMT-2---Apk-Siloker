</main>


</main>


<div class="container" style="margin-top:1rem;">
  <div class="row">
    <div class="col-lg-11">
      <div class="card">
        <div class="card-body">



<!-- Footer -->
<div class="page-footer font-small blue-grey lighten-5">

  <div style="background-color: #ffffff;">


      <!-- Grid row-->
      <div class="row py-4 d-flex align-items-center" style="padding-top:1rem">

        <!-- Grid column -->
        <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
          <h6 class="mb-0">Get connected with us on social networks!</h6>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-6 col-lg-7 text-center text-md-right">

          <!-- Facebook -->
          <a class="fb-ic">
            <i class="fa fa-facebook-f white-text mr-4"> </i>
          </a>
          <!-- Twitter -->
          <a class="tw-ic">
            <i class="fa fa-twitter white-text mr-4"> </i>
          </a>
          <!-- Google +-->
          <a class="gplus-ic">
            <i class="fa fa-google-plus white-text mr-4"> </i>
          </a>
          <!--Linkedin -->
          <a class="li-ic">
            <i class="fa fa-linkedin white-text mr-4"> </i>
          </a>
          <!--Instagram-->
          <a class="ins-ic">
            <i class="fa fa-instagram white-text"> </i>
          </a>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row-->


  </div>

  <!-- Footer Links -->
  <div class="container text-center text-md-left mt-5" id="footerUp">

    <!-- Grid row -->
    <div class="row mt-3 dark-grey-text">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-4 col-xl-3 mb-4">

        <!-- Content -->
        <h6 class="text-uppercase font-weight-bold">About This Theme</h6>
        <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>Siloker NF adalah website informasi lowongan kerja yang dibuat denga codeigniter V.3.1.11 dan Script PHP 5.6 untuk Praktikum Web</p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Informasi</h6>
        <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <a class="dark-grey-text" href="http://localhost/silokernf/page/about">About Us</a>
        </p>
        <p>
          <a class="dark-grey-text" href="http://localhost/silokernf/page/contact-us">Contact Us</a>
        </p>


      </div>
      <!-- Grid column -->



      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Contact</h6>
        <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <i class="fa fa-home mr-3"></i> Bogor, Jawa Barat</p>
        <p>
          <i class="fa fa-envelope mr-3"></i> SilokerNF2021@gmail.com</p>
        <p>
          <i class="fa fa-phone mr-3"></i> 0815-3847-355</p>
        <p>
          <i class="fa fa-whatsapp mr-3"></i> 0822-7922-3356</p>
        

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

</div>
<!-- Footer -->



            </div>
          </div>
        </div>
      </div>
    </div>
  
  
 <footer class="footer">
  <div class="container">
    <span class="text-muted" style="float:left"> Copyright © <?php echo date('Y')?> <?php echo namaSitus();?> All Right Reserved</span>
    <span class="text-muted" style="float:right; margin-right:6rem;" id="footerLeft"><?php echo kredit();?></span>
  </div>
</footer>
  
<script src="<?php echo base_url();?>assets/jquery.js"></script>
<script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-175206087-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-175206087-1');
</script>
  
<script src="<?php echo base_url();?>assets/jquery.js"></script>
<script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
