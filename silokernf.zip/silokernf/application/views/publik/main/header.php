<!DOCTYPE html>
<html lang="id-ID">
<head>
  <title><?php echo $title;?></title>
  <!-- Meta -->
  <meta name="robots" content="index">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="theme-color" content="#0055D9">
  <meta name="msapplication-navbutton-color" content="#4287f5">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="#4287f5">
  <meta name="keywords" content="lowongan, pekerjaan, rekrutmen, perusahaan">
  <meta name="description" content="<?php echo $deskripsi;?>">
  <link href="<?php echo current_url();?>" rel="canonical">
  <!-- End Meta -->
  <!-- Assets -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/font/css/font-awesome.min.css">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo base_url();?>assets/gambar/favicon.ico">
  <link rel="icon" type="image/png" href="<?php echo base_url();?>assets/gambar/favicon.ico">
  <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- OG: Facebook -->
  <meta property='og:site_name' content='<?php echo namaSitus();?>'/>
  <meta property='og:image' content='<?php echo base_url();?>assets/gambar/<?php echo logoSitus();?>'/>
  <meta property='og:title' content='<?php echo $title;?>'/>
  <meta property='og:description' content='<?php echo $deskripsi;?>'/>
  <meta property='og:type' content='article'/>
  <meta property='og:url' content='<?php echo current_url();?>'/>
  <!-- END OG: Facebook -->
  <!-- Card Twitter -->
  <meta name="twitter:card" content="summary" />
  <meta name="twitter:site" content="@<?php echo namaSitus();?>" />
  <meta name="twitter:title" content="<?php echo $title;?>" />
  <meta name="twitter:description" content="<?php echo $deskripsi;?>" />
  <meta name="twitter:image" content="<?php echo base_url();?>assets/gambar/<?php echo logoSitus();?>" />
  <!-- END Card Twitter -->
  <!-- Kode Adsense -->
  <?php
    if (kodeMainAdsense() == null) {
      echo "";
    }else {
      echo kodeMainAdsense();
    }
  ?>
  <!-- Schema Website -->
  <script type="application/ld+json"> { "@context": "https://schema.org/", "@type": "WebSite", "name": "<?php echo namaSitus();?>", "url": "<?php echo base_url();?>", "potentialAction": { "@type": "SearchAction", "target": "<?php echo base_url();?>job?key={search_term_string}", "query-input": "required name=search_term_string" } } </script>
      <script type='application/ld+json'>
{
  "@context": "http://schema.org",
  "@graph":
  [
  {
  "@type": "Webpage",
  "url": "<?php echo base_url();?>",
  "name": "<?php echo namaSitus();?>",
  "headline":"<?php echo namaSitus();?>",
  "description": "<?php echo namaSitus();?> - <?php echo namaSitus();?> - <?php echo deskripsiSitus();?>",
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "<?php echo base_url();?>"
  },
  "publisher": {
    "@type": "Organization",
    "name": "<?php echo namaSitus();?>",
    "url": "<?php echo base_url();?>",
    "logo": {
        "url": "<?php echo base_url();?>assets/gambar/<?php echo logoSitus();?>",
        "width": 600,
        "height": 60,
        "@type": "ImageObject"
    }
  },
  "image": {
    "@type": "ImageObject",
    "url": "https://1.bp.blogspot.com/-YDvkfjfGDbA/XkJrKWEXNTI/AAAAAAABDJs/zvPePNb_xF47M3YE6yBG3SgyjzQdWeywgCLcBGAsYHQ/google-logo.JPG",
    "width": 1280,
    "height": 720
    }
  },
  {
  "@type": "WebSite",
  "url": "<?php echo base_url();?>",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "<?php echo base_url();?>job?key={search_term_string}",
    "query-input": "required name=search_term_string" }
    }
  ]
}
</script>
<!-- CSS Tambahan -->
<style>
body {
  font-size:14px;
  line-height:1.5;
  display: flex;
  min-height: 100vh;
  flex-direction: column
}
main { flex: 1 0 auto; }
.card-job{
  overflow: hidden;
  border-bottom: 1px solid #eee;
  padding: 15px 0;
}
.job-title{
  font-weight: 700;
  font-size: 1.1em;
  float: left;
  margin-bottom: 0;
  margin-top: 0;
  padding-right: 5px;
}
.job-title a:visited {
  color: #609;
}
.footer{
  margin-top:1rem;
  bottom: 0;
  width: 100%;
  height: 60px;
  line-height: 60px;
  background-color: #f5f5f5;
}

.meta-job{
  line-height: 1.9;
  color: #999;
  font-size: .8em;
  margin-left: 5px;
}
.meta-job a{
  color: #777;
}
.new-time {
  white-space: nowrap;
  overflow: hidden;
}
.logo-perusahaan a img{
  display: block;
  max-height: 80px;
  max-width: 80px;
}
.btn-facebook {
  color: #fff;
  background-color: #4C67A1;
}
.btn-facebook:hover {
  color: #fff;
  background-color: #405D9B;
}
.btn-facebook:focus {
  color: #fff;
}
.btn-twitter {
  color: #fff;
  background-color: #55acee;
}
.btn-twitter:hover {
  color: #fff;
  background-color: #4fa6e8;
}
.btn-twitter:focus {
  color: #fff;
}
.btn-linkedin {
  color: #fff;
  background-color: #0074A1;
}
.btn-linkedin:hover {
  color: #fff;
  background-color: #036b94;
}
.btn-linkedin:focus {
  color: #fff;
}
.btn-whatsapp {
  color: #fff;
  background-color: #34AF23;
}
.btn-whatsapp:hover {
  color: #fff;
  background-color: #29961a;
}
.btn-whatsapp:focus {
  color: #fff;
}
  
@media (min-width:990px){
  #logoHeader{margin-left:6.7rem}
  #navbarTogglerDemo02{margin-right:12.3rem}
}
@media (max-width:1023px) {
  #cardFilter{display:none}
}
@media (min-width:769px){
  .btn-whatsapp{display:none}
}
/* @media (max-width:765px){
.logo-perusahaan{display:none}
} */
@media only screen and (max-width: 767px) { #footerLeft { display:none } }
</style>
</head>
<body>
  <header>
    <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light" style="border-bottom:1px solid #4444">
      <a class="navbar-brand" id="logoHeader" href="<?php echo base_url();?>">
        <img src="<?php echo base_url();?>assets/gambar/<?php echo logoSitus();?>" alt="Logo <?php echo namaSitus();?>" width="160" height="40" class="d-inline-block align-top" alt="" loading="lazy">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
          <?php foreach (pageSitus() as $look) {?>
            <li style="font-size:16px" id="#<?php echo str_replace(" ","-",strtolower($look->judul_page));?>" class="nav-item">
              <a class="nav-link" href="<?php echo base_url();?>page/<?php echo str_replace(" ","-",strtolower($look->judul_page));?>"><strong><?php echo $look->judul_page;?></strong></span></a>
            </li>
          <?php }?>
        </ul>
        <form class="form-inline my-2 my-lg-0" action="<?php echo base_url();?>job" method="get" role="search">
          <div class="input-group ">
            <input type="text" class="form-control" placeholder="Cari Loker" name="key" id="key" aria-label="Recipient's username" aria-describedby="button-addon2">
            <div class="input-group-append">
              <button class="input-group-text" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
            </div>
          </div>
        </form>
  
      </div>

    </nav>
  </header>
  <main>
    <div class="container">
      <div class="col-md-12" style="margin-top:5rem;">
        <!-- Kode Adsense -->
        <?php
        if (kodeHeaderAdsense() == null) {
          echo "";
        }else {
          echo kodeHeaderAdsense();
        }
        ?>
      </div>
    </div>
