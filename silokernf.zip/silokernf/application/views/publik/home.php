<div class="container" style="margin-top:1rem;">
  <div class="row">
 
    <div class="col-lg-8 col-xs-12">
      <div class="card">
        <div class="card-body">
          <h1 class="card-title" style="font-size:1.4em">Jelajahi Lowongan (<?php echo totalArtikel();?>)</h1><hr>
          <?php $i=0; foreach ($artikel->result() as $look) { $i++;?>
            <div class="card-job row">
              <div class="col-md-10 col-sm-12">
                <div class="new-time">
                  <h2 class="job-title"><a title="<?php echo $look->judul_pekerjaan;?>" href="<?php echo base_url();?><?php echo $look->slug;?>/<?php echo $look->id_artikel;?>"><span><?php echo $look->judul_pekerjaan;?></span></a></h2><br>
                  <span class="meta-job"style="font-size:13px;"> <i class="fa fa fa-clock-o" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo $look->tanggal_posting;?></span><br>
                  <span class="meta-job" style="font-size:13px;"> <i class="	fa fa-dollar" aria-hidden="true"></i> &nbsp;&nbsp;Rp. <?php echo number_format($look->gaji_min,0,',','.');?>
                    <?php if ($look->gaji_max == 0) {
                    echo "";
                  }else {
                    echo "- ".number_format($look->gaji_max,0,',','.');
                  }
                  ?>
                  </span><br>
                  <span class="meta-job" style="font-size:13px"> <i class="fa fa-building-o" aria-hidden="true"></i> &nbsp;<?php echo $look->nama_perusahaan;?>
                  </span><br>
                  <span class="meta-job" style="font-size:13px"> <i class="fa fa fa-map-marker" aria-hidden="true"></i></span><span class="meta-job">&nbsp;&nbsp;<?php echo $look->name;?></span>
                </div>
              </div>
              <div class="logo-perusahaan col-xs-4 col-md-2">
                <a href="<?php echo base_url();?><?php echo $look->slug;?>/<?php echo $look->id_artikel;?>" title="Lowongan Kerja di <?php echo $look->nama_perusahaan;?>"><img src="<?php echo base_url();?>assets/gambar/perusahaan/<?php echo $look->gambar;?>" alt="<?php echo $look->judul_seo;?>"></a>
              </div>
            </div>
            <?php if($i==2){
              echo "
                <div class='col-md-12' style='margin-top:1rem;margin-bottom=1rem;'>".
                    kodeHomeAdsense()
                ."</div>
              ";
            }elseif($i==4){
                echo "
                <div class='col-md-12' style='margin-top:1rem;margin-bottom=1rem;'>".
                    kodeHomeAdsense()
                ."</div>
              ";
            }?>
          <?php }?>
          <div class="row" style="margin-top:2rem;">
            <div class="col-md-12">
              <?php echo $pagination;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    
       <div class="col-md-4 col-xs-12">
      <div class="card" id="cardFilter" style="width: 16rem;">
        <div class="card-title" style="font-size:1.2em; height:3.0rem; text-align:center;padding-top:1rem;"><b>Filter Lowongan Kerja</b></div>
        <ul class="list-group list-group-flush">
          <li class="list-group-item"><span style="font-size:1.2em;">Pilih Lokasi</span></li>
        </ul>
        <ul style="margin-top:1rem;">
          <?php foreach (getLokasi()->result() as $look) {?>
            <?php
            $kabupaten = explode(" ",$look->name);
            $kabupaten = strtolower($kabupaten[1]);
            ?>
            <li class="checkbox">
              <label class="form-check-label"><a href="<?php echo base_url();?>job?key=<?php echo ucfirst($kabupaten);?>" style="color:#000"><?php echo ucfirst($kabupaten);?></a></label>
            </li>
          <?php } ?>
        </ul>
        <ul class="list-group list-group-flush">
          <li class="list-group-item"><span style="font-size:1.2em;">Pilih Kategori</span></li>
        </ul>
        <ul style="margin-top:1rem;">
          <?php foreach (getKategori()->result() as $look) {?>
            <li class="checkbox">
              <label class="form-check-label"><a href="<?php echo base_url();?>job?key=<?php echo $look->kategori;?>" style="color:#000"><?php echo $look->kategori;?></a></label>
            </li>
          <?php }?>
        </ul>
      </div>
    </div>
    
  </div>
</div>
