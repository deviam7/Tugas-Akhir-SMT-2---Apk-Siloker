<div class="row">
  <div class="col-12">
    <form action="<?php echo base_url();?>admin/proses/kategori/tambahKategori/" method="post" enctype="multipart/form-data">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Tambah Perusahaan</h3>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="namaPerusahaan">Kategori</label>
                <input type="text" name="namaKategori" class="form-control" id="namaKategori" required>
              </div>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Tambah</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
var base = "<?php echo base_url();?>"
$(document).ready(function(){
  $('#linkTambahKategori').addClass('active')
  $('#dropdownlinkKategori').addClass('menu-open')
})
</script>
