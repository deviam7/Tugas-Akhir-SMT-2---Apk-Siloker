<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title" style="padding-top:10px;">Daftar Kategori</h3> 
        <div class="row">
  <div class="col-md-12">
    <button type="button" onclick="tambahKategori()" style="float:right" class="btn btn-primary"><i class="fa fa-plus-square" aria-hidden="true"></i> Tambah Kategori</button>
  </div>
</div>
        
        

      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-12" style="overflow-x:auto;">
            <table class="table table-hover text-nowrap" id="tableData">
              <thead>
                <tr>
                  <th width="10%">No</th>
                  <th><center>Kategori</center></th>
                  <th><center>Action</center></th>
                </tr>
              </thead>
              <tbody>
                <?php $no=1; foreach ($kategori as $look) {?>
                  <tr>
                    <td><?php echo $no++;?></td>
                    <td><center><?php echo $look->kategori;?></center></td>
                    <td>
                      <center><i onclick="editKategori(<?php echo $look->id_kategori;?>,'<?php echo $look->kategori;?>')" style="margin-right:1.5rem;cursor:pointer" class="fa fa-pencil"></i> <i onclick="hapusKategori(<?php echo $look->id_kategori;?>,'<?php echo $look->kategori;?>')" style="cursor:pointer" class="fa fa-trash"></i></center>
                    </td>
                  </tr>
                <?php }?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- Tambah Kategori -->
<div class="modal fade" id="modalKategori" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="<?php echo base_url();?>admin/proses/kategori/tambahKategori" method="post" enctype="multipart/form-data">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Tamabah Kategori</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
              <div class="form-group">
                <label for="namaPerusahaan">Kategori</label>
                <input type="text" name="namaKategori" class="form-control" id="namaKategori" required>
              </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Tambah</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
var base = "<?php echo base_url();?>"
$(document).ready(function(){
  $('#linkDaftarKategori').addClass('active')
  $('#dropdownlinkKategori').addClass('menu-open')
})

function hapusKategori(id,kategori){
  Swal.fire({
    title: 'Alert!!!',
    text: 'Apa anda Yakin Hapus '+kategori+' ?',
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3366cc',
    cancelButtonText: 'Cancel!',
    confirmButtonText: 'IYA!'
  }).then((result) => {
    if (result.value) {
      window.location.href = '<?php echo base_url();?>admin/proses/kategori/hapusKategori/'+id
    }
  })
}

function editKategori(id,kategori) {
  Swal.fire({
    title: 'Update Kategori '+kategori+'',
    input: 'text',
    inputAttributes: {
      autocapitalize: 'off'
    },
    showCancelButton: true,
    confirmButtonText: 'Update',
    showLoaderOnConfirm: true,
    preConfirm: (kategori) => {
       window.location.href= base+"admin/proses/kategori/updateKategori/"+id+"/"+kategori
    },
    allowOutsideClick: () => !Swal.isLoading()
  })
}

function tambahKategori() {
  $('#modalKategori').modal('show')

}
</script>
