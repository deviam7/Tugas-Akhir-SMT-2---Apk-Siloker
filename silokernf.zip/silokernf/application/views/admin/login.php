<!DOCTYPE html>
<html>
<head>
  <title><?php echo $title;?> - <?php echo namaSitus();?></title>
  <meta name="robots" content="noindex">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="<?php echo base_url();?>assets/js/jquery.js"></script>
  <!--Import Google Icon Font-->

<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


  <script src="https://cdn.ckeditor.com/4.5.6/standard/ckeditor.js"></script>
  <script src="<?php echo base_url();?>assets/js/swal.js"></script>

  <style>

  </style>
</head>
<body>


    <div class="container">    
        <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-5 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
            <div class="panel panel-primary" >
                    <div class="panel-heading">
                        <div class="panel-title" style="text-align:center;">Login <?php echo namaSitus();?></div>
                    </div>     

                    <div style="padding-top:30px" class="panel-body" >

                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
                            
                        <form id="loginform" class="form-horizontal" method="post" action="<?php echo base_url();?>login/auth" enctype="multipart/form-data">
                                    
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input id="username" type="text" class="form-control" name="username" value="" placeholder="Username" required>                                        
                                    </div>
                                
                            <div style="margin-bottom: 20px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
                                    </div>
                                    

                                
                            <div class="input-group">
                                      <div class="checkbox">
                                        <label>
                                          <input id="login-remember" type="checkbox" name="remember" value="1"> Remember me
                                        </label>
                                      </div>
                                    </div>


                                <div style="margin-top:12px" class="form-group">
                                    <!-- Button -->

                                    <div class="col-sm-12 controls">

<button type="submit" name="btn_login" class="btn btn-primary" style="width:112px;">Login</button>


                                    </div>
                                </div>
   
                            </form>     



                        </div>                     
                    </div>  
        </div>
    </div>


</body>
</html>
