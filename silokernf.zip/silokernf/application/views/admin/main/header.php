<!DOCTYPE html>
<html lang="id">
<head>
  <meta name="robots" content="noindex">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title><?php echo $title;?> - <?php echo namaSitus();?></title>
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo base_url();?>assets/gambar/favicon.ico">
  <link rel="icon" type="image/png" href="<?php echo base_url();?>assets/gambar/favicon.ico">
  <script src="<?php echo base_url();?>assets/js/jquery.js"></script>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/lte/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/lte/dist/css/adminlte.min.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo base_url();?>/assets/font/css/font-awesome.min.css">
  <script src="https://cdn.ckeditor.com/4.5.6/standard/ckeditor.js"></script>
  <script src="<?php echo base_url();?>assets/js/swal.js"></script>
  <script type="text/javascript" src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
  <link type="text/css" rel="stylesheet" href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css"/>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/lte/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/lte/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <script src="<?php echo base_url();?>assets/lte/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url();?>assets/lte/plugins/select2/js/select2.full.min.js"></script>
  <script src="<?php echo base_url();?>assets/lte/dist/js/adminlte.js"></script>
</head>
<body class="hold-transition sidebar-mini">
  <div class="wrapper">

  <header>
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" data-widget="control-sidebar" data-slide="true" onclick="modalLogout()" style="cursor:pointer" role="button"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
        </li>
      </ul>
    </nav>
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <a href="<?php echo base_url();?>" class="brand-link">
        <center><img src="<?php echo base_url();?>assets/gambar/<?php echo logoSitus();?>" alt="Logo <?php echo namaSitus();?>" width="160" height="40" class="d-inline-block align-top" alt="" loading="lazy"></center>
      </a>
      <div class="sidebar">
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
              
              <li class="nav-item">
              <a href="<?php echo base_url();?>admin/tampil/" id="linkDaftarKategori" class="nav-link"><i class="nav-icon fa fa-dashboard"></i><p>Dashboard</p></a>
            </li>  
            <li class="nav-item has-treeview" id="dropdownlinkArtikel">
              <a href="#" class="nav-link" id="linkArtikel">
                <i class="nav-icon fa fa-suitcase"></i>
                <p>Job Listings<i class="right fas fa-angle-left"></i></p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="<?php echo base_url();?>admin/tampil/daftarArtikel" id="linkDaftarArtikel" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>All Jobs</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo base_url();?>admin/tampil/tambahArtikel" id="linkTambahArtikel" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Add New Job</p>
                  </a>
                </li>
              </ul>
            </li>
            <li class="nav-item has-treeview" id="dropdownlinkPerusahaan">
              <a href="#" class="nav-link" id="linkPerusahaan">
                <i class="nav-icon fa fa-building-o"></i>
                <p>Perusahaan<i class="right fas fa-angle-left"></i></p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="<?php echo base_url();?>admin/tampil/daftarPerusahaan" id="linkDaftarPerusahaan" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Daftar Perusahaan</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo base_url();?>admin/tampil/tambahPerusahaan" id="linkTambahPerusahaan" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Tambah Perusahaan</p>
                  </a>
                </li>
              </ul>
            </li>
            <li class="nav-item">
              <a href="<?php echo base_url();?>admin/tampil/daftarKategori" id="linkDaftarKategori" class="nav-link"><i class="nav-icon fa fa-server"></i><p>Kategori</p></a>
            </li>
            <li class="nav-item">
              <a href="<?php echo base_url();?>admin/tampil/lamanWeb" id="linkLaman" class="nav-link"><i class="nav-icon fa fa-book"></i><p>Laman</p></a>
            </li>
            <li class="nav-item">
              <a href="<?php echo base_url();?>admin/tampil/infoSitus" id="linkSitus" class="nav-link"><i class="nav-icon fa fa-wrench"></i><p>Info Situs</p></a>
            </li>
            <li class="nav-item">
              <a href="<?php echo base_url();?>admin/tampil/iklanSitus" id="linkIklan" class="nav-link"><i class="nav-icon fa fa-usd"></i><p>Kode Iklan</p></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" onclick="modalLogout()" style="cursor:pointer" role="button">&nbsp;<i class="fa fa-sign-out"></i><p>&nbsp;&nbsp;Logout</p></a>
            </li>
          </ul>
        </nav>
      </div>
    </aside>
  </header>
<main>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="container-fluid">
