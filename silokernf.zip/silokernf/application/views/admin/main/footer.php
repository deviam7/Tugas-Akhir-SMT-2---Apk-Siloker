<!-- !!Body -->
</div>
</section>
</div>
</div>


</main>
<script>
$(document).ready(function(){
  $("#tableData").DataTable({
        "responsive": true,
        "autoWidth": false,
  });
});

function modalLogout() {
  Swal.fire({
    title: 'Logout???',
    text: "Apa anda Yakin Mau Logout?",
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#26a69a',
    cancelButtonText: 'Cancel!',
    confirmButtonText: 'IYA!'
  }).then((result) => {
    if (result.value) {
      window.location.href = '<?php echo base_url();?>login/logout/'
    }
  })
}
</script>

</body>
</html>
