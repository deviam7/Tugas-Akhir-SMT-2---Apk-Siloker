<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Daftar Artikel</h3>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-12" style="overflow-x:auto;">
            <table class="table table-hover text-nowrap" id="tableData">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Judul Pekerjaan</th>
                  <th>Deskripsi Pekerjaan</th>
                  <th>Perusahaan</th>
                  <th>Kategori</th>
                  <th>Tanggal Publish</th>
                  <th>Tanggal Expired</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $no=1; foreach ($artikel->result() as $look) {?>
                  <tr>
                    <td><?php echo $no++;?></td>
                    <td><?php echo $look->judul_pekerjaan;?></td>
                    <td><?php echo $look->judul_seo;?></td>
                    <td><?php echo $look->nama_perusahaan;?></td>
                    <td><?php echo $look->kategori;?></td>
                    <td><?php echo $look->tanggal_posting;?></td>
                    <td><?php echo $look->tanggal_tutup;?></td>
                    <td>
                      <center>
                        <a href="<?php echo base_url();?>admin/tampil/editArtikel/<?php echo $look->id_artikel;?>" style="color:#000"><i style="margin-right:1.5rem;cursor:pointer" class="fa fa-pencil"></i></a>
                        <i onclick="hapusArtikel(<?php echo $look->id_artikel;?>,'<?php echo $look->judul_seo;?>')" style="cursor:pointer" class="fa fa-trash"></i>
                      </center>
                    </td>
                  </tr>
                <?php }?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
var base = "<?php echo base_url();?>"
$(document).ready(function(){
  $('#linkDaftarArtikel').addClass('active')
  $('#dropdownlinkArtikel').addClass('menu-open')
})

// Hapus Artikel
function hapusArtikel(id,artikel) {
  Swal.fire({
    title: 'Alert!!!',
    text: 'Apa anda Yakin Menghapus Artikel '+artikel+' ?',
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3366cc',
    cancelButtonText: 'Cancel!',
    confirmButtonText: 'IYA!'
  }).then((result) => {
    if (result.value) {
      window.location.href = '<?php echo base_url();?>admin/proses/artikel/hapusArtikel/'+id
    }
  })
}
</script>
