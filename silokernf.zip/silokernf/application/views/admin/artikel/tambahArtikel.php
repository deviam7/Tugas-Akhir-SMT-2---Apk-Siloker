<div class="row">
  <div class="col-12">
    <form action="<?php echo base_url();?>admin/proses/artikel/tambahArtikel/" method="post" enctype="multipart/form-data">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Add New Job</h3>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="namaPerusahaan">Judul Pekerjaan / Posisi</label>
                <input type="text" name="judulPekerjaan" class="form-control" id="judulPekerjaan" required>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <textarea class="form-control" id="isiArtikel" name="isiArtikel" required></textarea>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 col-sm-12">
              <div class="form-group">
                <label for="idPerusahaan">Nama Perusahaan</label>
                <select class="form-control select2 select2-danger" id="idPerusahaan" name="idPerusahaan" style="width: 100%;">
                  <option disabled selected>- Pilih -</option>
                  <?php foreach ($perusahaan as $look) {?>
                    <option value="<?php echo $look->id_perusahaan;?>"><?php echo $look->nama_perusahaan;?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="form-group">
                <label for="idPerusahaan">Kategori</label>
                <select class="form-control select2 select2-danger" id="idKategori" name="idKategori" style="width: 100%;">
                  <option disabled selected>- Pilih -</option>
                  <?php foreach ($kategori as $look) {?>
                    <option value="<?php echo $look['id_kategori'];?>"><?php echo $look['kategori'];?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="form-group">
                <label for="waktuKerja">Waktu Kerja</label>
                <input type="number" min="1" name="waktuKerja" id="waktuKerja" class="form-control" required>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 col-sm-12">
              <div class="form-group">
                <label for="tanggalDibuka">Tanggal Dibuka</label>
                <input type="date" class="form-control" name="tanggalDibuka" id="tanggalDibuka" required>
              </div>
            </div>
            <div class="col-md-6 col-sm-12">
              <div class="form-group">
                <label for="tanggalDibuka">Tanggal Ditutup</label>
                <input type="date" class="form-control" name="tanggalDitutup" id="tanggalDitutup" required>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="waktuKerja">Street</label>
                <input type="text" name="street" id="street" class="form-control" required>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 col-xs-12">
              <div class="form-group">
                <label for="provinsi">Provinsi</label>
                <select class="form-control select2 select2-danger" id="provinsi" name="provinsi" style="width: 100%;">
                  <option disabled selected>- Pilih -</option>
                  <?php foreach ($provinsi as $look) {?>
                    <option value="<?php echo $look['id'];?>"><?php echo $look['name_provinces'];?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="col-md-4 col-xs-12">
              <div class="form-group">
                <label for="kabupaten">Kabupaten</label>
                <select class="form-control select2 select2-danger" id="kabupaten" name="kabupaten" style="width: 100%;">

                </select>
              </div>
            </div>
            <div class="col-md-4 col-xs-12">
              <div class="form-group">
                <label for="namaPerusahaan">Kode Pos</label>
                <input type="text" name="kodePos" class="form-control" id="kodePos" required>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <label for="emplyoment">Emplyoment</label>
              <select class="form-group custom-select" id="emplyoment" name="emplyoment" style="width: 100%;">
                <option disabled selected>- Pilih -</option>
                <option value="FULL_TIME">Full Time</option>
                <option value="PART_TIME">Part Time</option>
                <option value="CONTRACTOR">Contractor</option>
                <option value="TEMPORARY">Temporary</option>
              </select>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 col-xs-12">
              <div class="form-group">
                <label for="gajiMin">Gaji Min</label>
                <input min="1" type="number" name="gajiMin" class="form-control" id="gajiMin" required>
              </div>
            </div>
            <div class="col-md-6 col-xs-12">
              <div class="form-group">
                <label for="gajiMin">Gaji Max</label>
                <input type="number" name="gajiMax" class="form-control" id="gajiMax">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 col-sm-12">
              <div class="form-group">
                <label for="namaPerusahaan">Skills</label>
                <input type="text" name="skills" class="form-control" id="skills">
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="form-group">
                <label for="minimumPendidikan">Minimum Pendidikan</label>
                <select class="form-group custom-select" id="minimumPendidikan" name="minimumPendidikan" style="width: 100%;">
                  <option disabled selected>- Pilih -</option>
                  <option value="SD">SD</option>
                  <option value="SMP">SMP</option>
                  <option value="SMA/SMK">SMA/SMK</option>
                  <option value="D3">D3</option>
                  <option value="D4">D4</option>
                  <option value="S1">S1</option>
                </select>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="form-group">
                <label for="pengalamanBekerja">Pengalaman Kerja</label>
                <input type="number" min="0" name="pengalamanBekerja" class="form-control" id="pengalamanBekerja" required>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 col-sm-12">
              <div class="form-group">
                <label for="linkMelamar">Link Melamar</label>
                <input type="url" name="linkMelamar" class="form-control" id="linkMelamar">
              </div>
            </div>
            <div class="col-md-6 col-sm-12">
              <div class="form-group">
                <label for="emailMelamar">Email Lamar</label>
                <input type="email" name="emailMelamar" class="form-control" id="emailMelamar">
              </div>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn btn-primary"> Publish</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
var base = "<?php echo base_url();?>"
$(document).ready(function(){
  $('#linkTambahArtikel').addClass('active')
  $('#dropdownlinkArtikel').addClass('menu-open')
  $('.select2').select2()
  $('.select2bs4').select2({
    theme: 'bootstrap4'
  })
})

$(function(){
  $("#provinsi").change(function(){
    $.ajaxSetup({
      type:"POST",
      url: "<?php echo base_url('admin/tampil/getKabupaten') ?>",
      cache: false,
    });
    var value=$(this).val();
    if(value>0){
      $.ajax({
        data:{modul:'kabupaten',id:value},
        success: function(respond){
          $("#kabupaten").html(respond);
        }
      })
    }
  });
})
CKEDITOR.replace('isiArtikel');
</script>
