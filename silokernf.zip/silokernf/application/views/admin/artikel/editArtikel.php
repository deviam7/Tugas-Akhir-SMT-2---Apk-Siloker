<div class="row">
  <div class="col-12">
    <form action="<?php echo base_url();?>admin/proses/artikel/updateArtikel/" method="post" enctype="multipart/form-data">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Edit Lowongan Kerja (<?php echo $id;?>)</h3>
        </div>
        <?php foreach ($artikel as $record) {?>
          <div class="card-body">
              <input type="hidden" name="idArtikel" value="<?php echo $record->id_artikel;?>">
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="namaPerusahaan">Judul Pekerjaan</label>
                  <input type="text" name="judulPekerjaan" class="form-control" value="<?php echo $record->judul_pekerjaan;?>" id="judulPekerjaan" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <textarea class="form-control" id="isiArtikel" name="isiArtikel"><?php echo $record->deskripsi_pekerjaan;?></textarea>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-4 col-sm-12">
                <div class="form-group">
                  <label for="idPerusahaan">Nama Perusahaan</label>
                  <select class="form-control select2 select2-danger" id="idPerusahaan" name="idPerusahaan" style="width: 100%;">
                    <option value="<?php echo $record->id_perusahaan;?>"><?php echo $record->nama_perusahaan;?></option>
                    <?php foreach ($perusahaan as $look) {?>
                      <option value="<?php echo $look->id_perusahaan;?>"><?php echo $look->nama_perusahaan;?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
              <div class="col-md-4 col-sm-12">
                <div class="form-group">
                  <label for="idKategori">Kategori</label>
                  <select class="form-control select2 select2-danger" id="idKategori" name="idKategori" style="width: 100%;">
                    <option value="<?php echo $record->id_kategori;?>"><?php echo $record->kategori;?></option>
                    <?php foreach ($kategori as $look) {?>
                      <option value="<?php echo $look['id_kategori'];?>"><?php echo $look['kategori'];?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
              <div class="col-md-4 col-sm-12">
                <div class="form-group">
                  <label for="waktuKerja">Waktu Kerja</label>
                  <input type="number" min="1" name="waktuKerja" id="waktuKerja" class="form-control" value="<?php echo $record->waktu_bekerja;?>" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 col-sm-12">
                <div class="form-group">
                  <label for="tanggalDibuka">Tanggal Dibuka</label>
                  <input type="date" class="form-control" value="<?php echo $record->tanggal_dibuka;?>" name="tanggalDibuka" id="tanggalDibuka" required>
                </div>
              </div>
              <div class="col-md-6 col-sm-12">
                <div class="form-group">
                  <label for="tanggalDibuka">Tanggal Ditutup</label>
                  <input type="date" class="form-control" value="<?php echo $record->tanggal_tutup;?>" name="tanggalDitutup" id="tanggalDitutup" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="waktuKerja">Street</label>
                  <input type="text" name="street" id="street" class="form-control" value="<?php echo $record->street;?>" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-4 col-xs-12">
                <div class="form-group">
                  <label for="provinsi">Provinsi</label>
                  <select class="form-control select2 select2-danger" id="provinsi" name="provinsi" style="width: 100%;">
                    <?php foreach ($provinsi as $look) {?>
                      <option value="<?php echo $look['id'];?>"
                        <?php if ($record->provinsi == $look['id']): ?>
                          selected="selected"
                        <?php endif; ?>><?php echo $look['name_provinces'];?>
                      </option>
                    <?php } ?>
                  </select>
                </div>
              </div>
              <div class="col-md-4 col-xs-12">
                <div class="form-group">
                  <label for="kabupaten">Kabupaten</label>
                  <select class="form-control select2 select2-danger" id="kabupaten" name="kabupaten" style="width: 100%;">
                    <option value="<?php echo $record->kabupaten;?>"><?php echo $record->name;?></option>
                  </select>
                </div>
              </div>
              <div class="col-md-4 col-xs-12">
                <div class="form-group">
                  <label for="namaPerusahaan">Kode Pos</label>
                  <input type="text" name="kodePos" class="form-control" value="<?php echo $record->kode_pos;?>" id="kodePos" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <label for="emplyoment">Emplyoment</label>
                <select class="form-group custom-select" id="emplyoment" name="emplyoment" style="width: 100%;">
                  <?php if ($record->emplyoment== "FULL_TIME") {?>
                    <option value="FULL_TIME" selected="selected">Full Time</option>
                    <option value="PART_TIME">Part Time</option>
                    <option value="CONTRACTOR">Contractor</option>
                    <option value="TEMPORARY">Temporary</option>
                  <?php }elseif ($record->emplyoment== "PART_TIME") {?>
                    <option value="FULL_TIME">Full Time</option>
                    <option value="PART_TIME" selected="selected">Part Time</option>
                    <option value="CONTRACTOR">Contractor</option>
                    <option value="TEMPORARY">Temporary</option>
                  <?php }elseif ($record->emplyoment== "CONTRACTOR") {?>
                    <option value="FULL_TIME">Full Time</option>
                    <option value="PART_TIME">Part Time</option>
                    <option value="CONTRACTOR" selected="selected">Contractor</option>
                    <option value="TEMPORARY">Temporary</option>
                  <?php }else {?>
                    <option value="FULL_TIME">Full Time</option>
                    <option value="PART_TIME">Part Time</option>
                    <option value="CONTRACTOR">Contractor</option>
                    <option value="TEMPORARY" selected="selected">Temporary</option>
                  <?php }?>
                </select>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 col-xs-12">
                <div class="form-group">
                  <label for="gajiMin">Gaji Min</label>
                  <input min="1" type="number" name="gajiMin" class="form-control" value="<?php echo $record->gaji_min;?>" id="gajiMin" required>
                </div>
              </div>
              <div class="col-md-6 col-xs-12">
                <div class="form-group">
                  <label for="gajiMin">Gaji Max</label>
                  <input type="number" name="gajiMax" class="form-control" value="<?php echo $record->gaji_max;?>" id="gajiMax">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-4 col-sm-12">
                <div class="form-group">
                  <label for="namaPerusahaan">Skills</label>
                  <input type="text" name="skills" class="form-control" value="<?php echo $record->skills;?>" id="skills" required>
                </div>
              </div>
              <div class="col-md-4 col-sm-12">
                <div class="form-group">
                  <label for="minimumPendidikan">Minimum Pendidikan</label>
                  <select class="form-group custom-select" id="minimumPendidikan" name="minimumPendidikan" style="width: 100%;">
                    <?php if ($record->minimum_pendidikan== "SD") {?>
                      <option value="SD" selected="selected">SD</option>
                      <option value="SMP">SMP</option>
                      <option value="SMA/SMK">SMA/SMK</option>
                      <option value="D3">D3</option>
                      <option value="D4">D4</option>
                      <option value="S1">S1</option>
                    <?php }elseif ($record->minimum_pendidikan== "SMP") {?>
                      <option value="SD">SD</option>
                      <option value="SMP" selected="selected">SMP</option>
                      <option value="SMA/SMK">SMA/SMK</option>
                      <option value="D3">D3</option>
                      <option value="D4">D4</option>
                      <option value="S1">S1</option>
                    <?php }elseif ($record->minimum_pendidikan== "SMA/SMK") {?>
                      <option value="SD" >SD</option>
                      <option value="SMP">SMP</option>
                      <option value="SMA/SMK" selected="selected">SMA/SMK</option>
                      <option value="D3">D3</option>
                      <option value="D4">D4</option>
                      <option value="S1">S1</option>
                    <?php }elseif ($record->minimum_pendidikan== "D3") {?>
                      <option value="SD" >SD</option>
                      <option value="SMP">SMP</option>
                      <option value="SMA/SMK">SMA/SMK</option>
                      <option value="D3" selected="selected">D3</option>
                      <option value="D4">D4</option>
                      <option value="S1">S1</option>
                    <?php }elseif ($record->minimum_pendidikan== "D4") {?>
                      <option value="SD" >SD</option>
                      <option value="SMP">SMP</option>
                      <option value="SMA/SMK">SMA/SMK</option>
                      <option value="D3">D3</option>
                      <option value="D4" selected="selected">D4</option>
                      <option value="S1">S1</option>
                    <?php }else {?>
                      <option value="SD" >SD</option>
                      <option value="SMP">SMP</option>
                      <option value="SMA/SMK">SMA/SMK</option>
                      <option value="D3">D3</option>
                      <option value="D4">D4</option>
                      <option value="S1" selected="selected">S1</option>
                    <?php }?>
                  </select>
                </div>
              </div>
              <div class="col-md-4 col-sm-12">
                <div class="form-group">
                  <label for="pengalamanBekerja">Pengalaman Kerja</label>
                  <input type="number" min="0" name="pengalamanBekerja" class="form-control" value="<?php echo $record->pengalaman_kerja;?>" id="pengalamanBekerja" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 col-sm-12">
                <div class="form-group">
                  <label for="linkMelamar">Link Melamar</label>
                  <input type="url" name="linkMelamar" class="form-control" value="<?php echo $record->link_lamar;?>" id="linkMelamar">
                </div>
              </div>
              <div class="col-md-6 col-sm-12">
                <div class="form-group">
                  <label for="emailMelamar">Email Lamar</label>
                  <input type="email" name="emailMelamar" class="form-control" value="<?php echo $record->email_lamar;?>" id="emailMelamar">
                </div>
              </div>
            </div>
          </div>
        <?php } ?>
        <div class="card-footer">
          <button type="submit" class="btn btn-primary"> Update</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
var base = "<?php echo base_url();?>"
$(document).ready(function(){
  $('#linkDaftarArtikel').addClass('active')
  $('#dropdownlinkArtikel').addClass('menu-open')
  $('.select2').select2()
  $('.select2bs4').select2({
    theme: 'bootstrap4'
  })
})

$(function(){
  $("#provinsi").change(function(){
    $.ajaxSetup({
      type:"POST",
      url: "<?php echo base_url('admin/tampil/getKabupaten') ?>",
      cache: false,
    });
    var value=$(this).val();
    if(value>0){
      $.ajax({
        data:{modul:'kabupaten',id:value},
        success: function(respond){
          $("#kabupaten").html(respond);
        }
      })
    }
  });
})
// CKEDITOR
CKEDITOR.replace('isiArtikel');
</script>
