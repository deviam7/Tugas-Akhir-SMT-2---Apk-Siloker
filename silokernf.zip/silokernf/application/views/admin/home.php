<div class="row">
  <div class="col-md-4 col-xs-12">
    <div class="small-box bg-info">
      <div class="inner">
        <h3><?php echo totalArtikel();?></h3>
        <p>Total Lowongan Kerja</p>
      </div>
      <div class="icon">
        <i class="fa fa-file-o" aria-hidden="true"></i>
      </div>
      <a href="<?php echo base_url();?>admin/tampil/daftarArtikel" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
    </div>
  </div>
  <div class="col-md-4 col-xs-12">
    <div class="small-box bg-success">
      <div class="inner">
        <h3><?php echo totalUser();?></h3>
        <p>Total User</p>
      </div>
      <div class="icon">
        <i class="fa fa-user" aria-hidden="true"></i>
      </div>
      <a href="<?php echo base_url();?>admin/tampil/infoSitus" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
    </div>
  </div>
  <div class="col-md-4 col-xs-12">
    <div class="small-box bg-warning">
      <div class="inner">
        <h3><?php echo totalPerusahaan();?></h3>
        <p>Total Perusahaan</p>
      </div>
      <div class="icon">
        <i class="fa fa-building-o" aria-hidden="true"></i>
      </div>
      <a href="<?php echo base_url();?>admin/tampil/daftarPerusahaan" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="small-box bg-danger">
      <div class="inner">
        <h3><?php echo totalKategori();?></h3>
        <p>Total Kategori</p>
      </div>
      <div class="icon">
        <i class="fa fa-list" aria-hidden="true"></i>
      </div>
      <a href="<?php echo base_url();?>admin/tampil/daftarKategori" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
    </div>
  </div>
</div>
