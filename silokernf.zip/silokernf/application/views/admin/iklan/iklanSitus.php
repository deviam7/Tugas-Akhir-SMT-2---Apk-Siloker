<div class="row">
  <div class="col-12">
    <?php foreach ($iklan->result() as $look) {?>
    <form action="<?php echo base_url();?>admin/proses/iklan/tambahIklan" method="post" enctype="multipart/form-data">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Iklan Situs</h3>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="namaPerusahaan">Kode Main Adsense</label>
                <textarea class="form-control" id="main" name="main"><?php echo $look->main;?></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="namaPerusahaan">Header</label>
                <textarea class="form-control" id="header" name="header"><?php echo $look->header;?></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="namaPerusahaan">Sidebar</label>
                <textarea class="form-control" id="sidebar" name="sidebar"><?php echo $look->sidebar;?></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="namaPerusahaan">Tengah</label>
                <textarea class="form-control" id="tengah" name="tengah" ><?php echo $look->tengah;?></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="namaPerusahaan">Link</label>
                <textarea class="form-control" id="url" name="url" ><?php echo $look->url;?></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="namaPerusahaan">Home</label>
                <textarea class="form-control" id="home" name="home" ><?php echo $look->home;?></textarea>
              </div>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Tambah</button>
        </div>
      </div>
    </form>
  <?php } ?>
  </div>
</div>

<script>
$(document).ready(function(){
  $('#linkIklan').addClass('active')
})
</script>
