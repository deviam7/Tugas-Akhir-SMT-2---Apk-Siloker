<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Daftar Perusahaan</h3>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-12" style="overflow-x:auto;">
            <table class="table table-hover text-nowrap" id="tableData">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Perusahaan</th>
                  <th>Deskripsi Perusahaan</th>
                  <th>Kuantitas Pekerja</th>
                  <th>Situs Perusahaan</th>
                  <th>Industri</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $no=1; foreach ($perusahaan as $look) {?>
                  <tr>
                    <td><?php echo $no++;?></td>
                    <td><?php echo $look->nama_perusahaan;?></td>
                    <td><?php echo $look->deskripsi_perusahaan;?></td>
                    <td><?php echo $look->kuantitas_pekerja;?> Orang</td>
                    <td><?php echo $look->url_perusahaan;?></td>
                    <td><?php echo $look->industri;?></td>
                    <td><i onclick="editPerusahaan(<?php echo $look->id_perusahaan;?>)" style="margin-right:1.5rem;cursor:pointer" class="fa fa-pencil"></i> <i onclick="hapusPerusahaan(<?php echo $look->id_perusahaan;?>,'<?php echo $look->nama_perusahaan;?>')" style="cursor:pointer" class="fa fa-trash"></i></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="modalEditPerusahaan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="<?php echo base_url();?>admin/proses/perusahaan/updatePerusahaan" method="post" enctype="multipart/form-data">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="labelEditPerusahaan"></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="idPerusahaan" name="idPerusahaan">
          <div class="form-group">
            <label for="namaPerusahaan">Nama Perusahaan</label>
            <input type="text" name="namaPerusahaan" class="form-control" id="namaPerusahaan" required>
          </div>
          <div class="form-group">
            <label for="deskripsiPerusahaan">Deskripsi Perusahaan</label>
            <input type="text" name="deskripsiPerusahaan" class="form-control" id="deskripsiPerusahaan" required>
          </div>
          <div class="form-group">
            <label for="kuantitasPekerja">Kuantitas Pekerja</label>
            <input type="number" name="kuantitasPekerja" class="form-control" id="kuantitasPekerja" required>
          </div>
          <div class="form-group">
            <label for="urlPerusahaan">URL Perusahaan</label>
            <input type="text" name="urlPerusahaan" class="form-control" id="urlPerusahaan">
          </div>
          <div class="form-group">
            <label for="industri">Industri</label>
            <input type="text" name="industri" class="form-control" id="industri" required>
          </div>
          <div class="form-group">
            <label for="gambar">Gambar</label>
            <div class="custom-file">
              <input type="file" class="custom-file-input" id="gambar" name="gambar">
              <label class="custom-file-label" for="customFile">Choose file</label>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
var base = "<?php echo base_url();?>"
$(document).ready(function(){
  $('#linkDaftarPerusahaan').addClass('active')
  $('#dropdownlinkPerusahaan').addClass('menu-open')
})

// Hapus Perusahaan
function hapusPerusahaan(id,perusahaan) {
  Swal.fire({
    title: 'Alert!!!',
    text: 'Apa anda Yakin Hapus '+perusahaan+' ?',
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3366cc',
    cancelButtonText: 'Cancel!',
    confirmButtonText: 'IYA!'
  }).then((result) => {
    if (result.value) {
      window.location.href = '<?php echo base_url();?>admin/proses/perusahaan/hapusPerusahaan/'+id
    }
  })
}

// Edit Perusahaan
function editPerusahaan(id) {
  $.ajax({
    url: base+"admin/proses/perusahaan/editPerusahaan/"+id,
    dataType: "JSON",
    success:function(data){
      $('#modalEditPerusahaan').modal('show')
      $('#idPerusahaan').val(id)
      $('#labelEditPerusahaan').html("Edit Perusahaan "+data.nama_perusahaan)
      $('#namaPerusahaan').val(data.nama_perusahaan)
      $('#deskripsiPerusahaan').val(data.deskripsi_perusahaan)
      $('#kuantitasPekerja').val(data.kuantitas_pekerja)
      $('#urlPerusahaan').val(data.url_perusahaan)
      $('#industri').val(data.industri)
    }
  })
}
</script>
