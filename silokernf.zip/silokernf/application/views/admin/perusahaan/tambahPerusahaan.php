<div class="row">
  <div class="col-12">
    <form action="<?php echo base_url();?>admin/proses/perusahaan/tambahPerusahaan/" method="post" enctype="multipart/form-data">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Tambah Perusahaan</h3>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-6 col-sm-12">
              <div class="form-group">
                <label for="namaPerusahaan">Nama Perusahaan</label>
                <input type="text" name="namaPerusahaan" class="form-control" id="namaPerusahaan" required>
              </div>
            </div>
            <div class="col-md-6 col-sm-12">
              <div class="form-group">
                <label for="deskripsiPerusahaan">Deskripsi Perusahaan</label>
                <textarea name="deskripsiPerusahaan" class="form-control" id="deskripsiPerusahaan" required></textarea>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 col-sm-12">
              <div class="form-group">
                <label for="kuantitasPekerja">Kuantitas Pekerja</label>
                <input type="number" name="kuantitasPekerja" min="1" class="form-control" id="kuantitasPekerja" required>
              </div>
            </div>
            <div class="col-md-6 col-sm-12">
              <div class="form-group">
                <label for="urlPerusahaan">URL Perusahaan (Opsional)</label>
                <input type="text" name="urlPerusahaan" class="form-control" id="urlPerusahaan">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 col-sm-12">
              <div class="form-group">
                <label for="industri">Industri</label>
                <input type="text" name="industri" class="form-control" id="industri" required>
              </div>
            </div>
            <div class="col-md-6 col-sm-12">
              <div class="form-group">
                <label for="gambar">Logo Perusahaan</label>
                <div class="custom-file">
                  <input type="file" class="custom-file-input" id="gambar" name="gambar">
                  <label class="custom-file-label" for="customFile">Choose file</label>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <button type="submit" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Tambah</button>
        </div>
      </div>
    </form>
  </div>
</div>
<script>
var base = "<?php echo base_url();?>"
$(document).ready(function(){
  $('#linkTambahPerusahaan').addClass('active')
  $('#dropdownlinkPerusahaan').addClass('menu-open')
})
</script>
