

<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title" style="padding-top:10px">Halaman Situs</h3>
        
        
      <div class="row">
  <div class="col-md-12">
    <button type="button" onclick="tambahLaman()" style="float:right" class="btn btn-primary"><i class="fa fa-plus-square" aria-hidden="true"></i> Tambah Laman</button>
  </div>
</div>  
        
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-12" style="overflow-x:auto;">
            <table class="table table-hover text-nowrap" id="tableData">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Judul</th>
                  <th>Isi Laman</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $no=1; foreach ($laman as $look) {?>
                  <tr>
                    <td><?php echo $no++;?></td>
                    <td><?php echo $look->judul_page;?></td>
                    <td><?php
                    $words = str_word_count($look->isi_page, 2);
                    $pos = array_keys($words);
                    echo substr($look->isi_page, 0, $pos[15]) . '...';
                    ?></td>
                    <td>
                      <center>
                        <i onclick="editLaman(<?php echo $look->id;?>)" style="margin-right:1.5rem;cursor:pointer" class="fa fa-pencil"></i>
                        <i onclick="hapusLaman(<?php echo $look->id;?>,'<?php echo $look->judul_page;?>')" style="cursor:pointer" class="fa fa-trash"></i>
                      </center>
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Edit Laman -->
<div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="<?php echo base_url();?>admin/proses/laman/updateLaman" method="post" enctype="multipart/form-data">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="labelEditLaman"></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="idLamanEdit" name="idLamanEdit">
          <div class="form-group">
            <label for="judulEdit">Judul Laman</label>
            <input type="text" name="judulEdit" class="form-control" id="judulEdit" required>
          </div>
          <div class="form-group">
            <textarea id="isiLamanEdit" name="isiLamanEdit" class="form-control" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Tambah Laman -->
<div class="modal fade" id="modalTambah" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="<?php echo base_url();?>admin/proses/laman/tambahLaman" method="post" enctype="multipart/form-data">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Tamabah Laman</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="judul">Judul Laman</label>
            <input type="text" name="judul" class="form-control" id="judul" required>
          </div>
          <div class="form-group">
            <textarea id="isiLaman" name="isiLaman" class="form-control" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
var base = "<?php echo base_url();?>"
$(document).ready(function(){
  $('#linkLaman').addClass('active')
})
// Hapus Laman
function hapusLaman(id,laman) {
  Swal.fire({
    title: 'Alert!!!',
    text: 'Yakin Mau Menghapus Laman '+laman+' ?',
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3366cc',
    cancelButtonText: 'Cancel!',
    confirmButtonText: 'IYA!'
  }).then((result) => {
    if (result.value) {
      window.location.href = '<?php echo base_url();?>admin/proses/laman/hapusLaman/'+id
    }
  })
}
// Edit Laman
function editLaman(id,laman) {
  $.ajax({
    url: base+"admin/proses/laman/editLaman/"+id,
    dataType: "JSON",
    success:function(data){
      $('#idLamanEdit').val(id)
      $('#modalEdit').modal('show')
      $('#labelEditLaman').html("Edit Laman "+data.judul_page)
      $('#judulEdit').val(data.judul_page)
      $('#isiLamanEdit').val(data.isi_page)
      CKEDITOR.replace('isiLamanEdit');
    }
  })
}
// Tamabah Laman
function tambahLaman() {
  $('#modalTambah').modal('show')
}
CKEDITOR.replace('isiLaman');
</script>
