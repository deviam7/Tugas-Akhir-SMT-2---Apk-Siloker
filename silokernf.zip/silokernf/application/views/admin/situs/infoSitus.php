<div class="row">
  <div class="col-md-4 col-sm-12">
    <!-- Widget: user widget style 1 -->
    <div class="card card-widget widget-user">
      <!-- Add the bg color to the header using any of the bg-* classes -->
      <div class="widget-user-header bg-info">
        <h3 class="widget-user-username"><?php echo $this->session->userdata('nama');?></h3>
        <h5 class="widget-user-desc">
          <?php  if ($this->session->userdata('level')) {
            echo "Admin";
          }else {
            echo "Penulis";
          }
          ?>
        </h5>
      </div>
      <div class="widget-user-image">
        <img class="img-circle elevation-2" src="<?php echo base_url();?>assets/gambar/<?php echo logoSitus();?>" alt="Logo <?php echo namaSitus();?>">
      </div>
      <div class="card-footer">
        <div class="row">
          <div class="col-md-8 col-sm-12 border-right border-left">
            <div class="description-block">
              <h5 class="description-header">Email</h5>
              <span class="description-text" style = "text-transform:lowercase;"><?php echo $this->session->userdata('email');?></span>
            </div>
          </div>
          <div class="col-md-4 col-sm-12 border-right border-left">
            <div class="description-block">
              <h5 class="description-header">Registered</h5>
              <span class="description-text"><?php echo $this->session->userdata('tgl_masuk');?></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-8 col-sm-12">
    <ul class="nav nav-tabs" role="tablist">
      <li class="nav-item">
        <a class="nav-link" href="#profileSitus" id="tabProfileSitus" role="tab" data-toggle="tab">Profile Situs</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#user" role="tab" id="tabUser" data-toggle="tab">User</a>
      </li>
    </ul>
    <div class="tab-content">
      <div role="tabpanel" class="tab-pane fade in" id="profileSitus">
        <?php foreach ($situs as $look) {?>
          <form action="<?php echo base_url();?>admin/proses/situs/updateSitus" method="post" enctype="multipart/form-data">
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="namaSitus">Nama Situs</label>
                  <input type="text" name="namaSitus" value="<?php echo $look->nama_situs;?>" class="form-control" id="namaSitus" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="slogan">Slogan</label>
                  <input type="text" name="slogan" value="<?php echo $look->slogan;?>" class="form-control" id="slogan" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="deskripsi">Deskripsi Situs</label>
                  <input type="text" name="deskripsi" value="<?php echo $look->deskripsi;?>" class="form-control" id="deskripsi" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="email">E-mail</label>
                  <input type="email" name="email" value="<?php echo $look->email;?>" class="form-control" id="email" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="gambar">Logo Website</label>
                  <div class="custom-file">
                    <input type="file" class="custom-file-input" id="gambar" name="gambar">
                    <label class="custom-file-label" for="customFile">Choose file</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <button type="submit" style="float:right" class="btn btn-primary">Update</button>
              </div>
            </div>
          </form>
        <?php } ?>
      </div>
      <div role="tabpanel" class="tab-pane fade" id="user">
        <div class="row">
          <div class="col-md-12" style="margin-top:1rem;">
            <button type="button" onclick="modalTambah()" style="float:right" class="btn btn-primary">Tambah User</button>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12" style="overflow-x:auto;margin-top:1rem;">
            <table class="table table-hover text-nowrap" id="tableData">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>E-mail</th>
                  <th>User</th>
                  <th>Password</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $no=1; foreach ($user as $look) {?>
                  <tr>
                    <td><?php echo $no++;?></td>
                    <td><?php echo $look->nama;?></td>
                    <td><?php echo $look->email;?></td>
                    <td><?php echo $look->user;?></td>
                    <td>********</td>
                    <td><?php
                    if($look->status == 0){
                      echo "Nonaktif";
                    }else {
                      echo "Aktif";
                    }
                    ?></td>
                    <td>
                      <?php
                      if ($look->level ==1) {?>
                        <i onclick="editUser(<?php echo $look->id_user;?>)" style="margin-right:1.5rem;cursor:pointer" class="fa fa-pencil"></i>
                      <?php }else{?>
                        <?php
                        if ($look->status == 1) {?>
                          <i onclick="editUser(<?php echo $look->id_user;?>)" style="margin-right:1.5rem;cursor:pointer" class="fa fa-pencil"></i>
                          <i onclick="nonaktifUser(<?php echo $look->id_user;?>,'<?php echo $look->nama;?>')" style="margin-right:1.5rem;cursor:pointer" class="fa fa-user-times"></i>
                        <?php }else{?>
                          <i onclick="aktifUser(<?php echo $look->id_user;?>,'<?php echo $look->nama;?>')" style="margin-right:1.5rem;cursor:pointer" class="fa fa-check"></i>
                        <?php } } ?>
                      </td>
                    </tr>
                  <?php }?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="modalEditUser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="<?php echo base_url();?>admin/proses/situs/updateUser" method="post" enctype="multipart/form-data">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="titleModal"></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="idUser" name="idUser">
          <div class="form-group">
            <label for="userEdit">UserName</label>
            <input type="text" disabled name="userEdit" class="form-control" id="userEdit" required>
          </div>
          <div class="form-group">
            <label for="namaEdit">Nama Pengguna</label>
            <input type="text" name="namaEdit" class="form-control" id="namaEdit" required>
          </div>
          <div class="form-group">
            <label for="emailEdit">E-Mail</label>
            <input type="email" name="emailEdit" class="form-control" id="emailEdit" required>
          </div>
          <div class="form-group">
            <label for="passEdit">Password</label>
            <input type="pass" name="passEdit" class="form-control" id="passEdit">
            <span>*Jika Tidak Ingin di Update, Kosongi!!!</span>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="modalTambah" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="<?php echo base_url();?>admin/proses/situs/tambahUser" method="post" enctype="multipart/form-data">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"> Tambah Pengguna</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="nama">Nama Pengguna</label>
            <input type="text" name="nama" class="form-control" id="nama" required>
          </div>
          <div class="form-group">
            <label for="user">UserName</label>
            <input type="text" name="user" class="form-control" id="user" required>
          </div>
          <div class="form-group">
            <label for="email">E-Mail</label>
            <input type="email" name="email" class="form-control" id="email" required>
          </div>
          <div class="form-group">
            <label for="pass">Password</label>
            <input type="password" name="pass" class="form-control" id="pass" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>
var base = "<?php echo base_url();?>"
$(document).ready(function(){
  $('#linkSitus').addClass('active')
})

function nonaktifUser(id,nama) {
  Swal.fire({
    title: 'Alert!!!',
    text: 'Yakin Mau Menonaktifkan '+nama+' ?',
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3366cc',
    cancelButtonText: 'Cancel!',
    confirmButtonText: 'IYA!'
  }).then((result) => {
    if (result.value) {
      window.location.href = '<?php echo base_url();?>admin/proses/situs/nonaktifUser/'+id
    }
  })
}

// Hapus User
function aktifUser(id,nama) {
  Swal.fire({
    title: 'Alert!!!',
    text: 'Yakin Mau Meng-aktifkan '+nama+' ?',
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3366cc',
    cancelButtonText: 'Cancel!',
    confirmButtonText: 'IYA!'
  }).then((result) => {
    if (result.value) {
      window.location.href = '<?php echo base_url();?>admin/proses/situs/aktifUser/'+id
    }
  })
}

function editUser(id) {
  $.ajax({
    url: base+"admin/proses/situs/editUser/"+id,
    dataType: "JSON",
    success:function(data){
      $('#modalEditUser').modal('show')
      $('#idPerusahaan').val(id)
      $('#idUser').val(id)
      $('#titleModal').html("Edit Pengguna "+data.nama)
      $('#namaEdit').val(data.nama)
      $('#userEdit').val(data.user)
      $('#emailEdit').val(data.email)
    }
  })
}

function modalTambah() {
  $('#modalTambah').modal('show')
}
</script>
