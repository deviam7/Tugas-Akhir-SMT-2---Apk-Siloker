<?php
defined('BASEPATH') or exot("No direct script access allowed");

class sitemap extends CI_Controller{

  function __construct(){
    parent::__construct();
    $this->load->model("publik/m_publik",'m_publik');
  }

  function index(){
    echo "belum ada";
  }

  function post(){
    $data['sitemap'] = $this->db->query("SELECT * FROM ket_artikel INNER JOIN artikel INNER JOIN info_perusahaan ON ket_artikel.id_artikel=artikel.id_artikel AND ket_artikel.id_perusahaan=info_perusahaan.id_perusahaan ORDER BY ket_artikel.id_artikel DESC")->result();
    $this->load->view('sitemap/posting',$data);
  }

  function page(){
    $data['page'] = $this->db->query("SELECT * FROM pages")->result();
    $this->load->view('sitemap/pages',$data);
  }
  function home(){
    $this->load->view("sitemap/home");
  }
}
