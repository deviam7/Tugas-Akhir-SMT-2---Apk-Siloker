<?php
defined('BASEPATH') or exit("No direct script access allowed");

class tampil extends CI_Controller{

  function __construct(){
    parent::__construct();
    // Cek Login
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }

    // Daftar Model
    $this->load->model("admin/m_kategori",'m_kategori');
    $this->load->model("admin/m_perusahaan",'m_perusahaan');
    $this->load->model("admin/m_artikel",'m_artikel');
    $this->load->model("admin/m_situs",'m_situs');
    $this->load->model("admin/m_laman","m_laman");
  }

  function index(){
    $data['title'] = "Dashboard";
    $this->load->view('admin/main/header',$data);
    $this->load->view('admin/home');
    $this->load->view('admin/main/footer');
  }

  // Artikel
  function daftarArtikel(){
    $data['artikel'] = $this->m_artikel->getArtikel();
    $data['title'] = "Daftar Artikel";
    $this->load->view('admin/main/header',$data);
    $this->load->view('admin/artikel/daftarArtikel');
    $this->load->view('admin/main/footer');
  }
  public function editArtikel($id){
    // Title
    $artikel = $this->db->query("SELECT * FROM ket_artikel WHERE id_artikel='$id'")->row();
    $data['title'] = "Edit Artikel ".$artikel->judul_seo;
    // Perlengkapan
    $data['kategori']= $this->m_artikel->getKategori();
    $data['provinsi'] = $this->m_artikel->getProvinsi();
    $data['perusahaan'] = $this->m_perusahaan->daftarPerusahaan()->result();
    $data['id'] = $id;
    // Ket Artikel
    $data['artikel'] = $this->db->query("SELECT * FROM ket_artikel a INNER JOIN artikel b INNER JOIN kategori c INNER JOIN info_perusahaan e INNER JOIN provinces f INNER JOIN regencies g on a.id_artikel=b.id_artikel and a.id_perusahaan=e.id_perusahaan and a.id_kategori=c.id_kategori and a.provinsi=f.id and a.kabupaten=g.id WHERE a.id_artikel='$id'")->result();
    $this->load->view('admin/main/header',$data);
    $this->load->view('admin/artikel/editArtikel');
    $this->load->view('admin/main/footer');
  }
  function tambahArtikel(){
    $data['kategori']= $this->m_artikel->getkategori();
    $data['provinsi'] = $this->m_artikel->getProvinsi();
    $data['perusahaan'] = $this->m_perusahaan->daftarPerusahaan()->result();
    $data['title'] = "Tambah Artikel";
    $this->load->view('admin/main/header',$data);
    $this->load->view('admin/artikel/tambahArtikel');
    $this->load->view('admin/main/footer');
  }
  // Get Kabupaten
  function getKabupaten(){
    $modul=$this->input->post('modul');
    $id=$this->input->post('id');
    if($modul=="kabupaten"){
      echo $this->m_artikel->getKabupaten($id);
    }
  }
  // End Get Kabupaten
  // Get Posisi
  function getPosisi(){
    $modul=$this->input->post('modul');
    $id=$this->input->post('id');
    if($modul=="posisi"){
      echo $this->m_artikel->getPosisi($id);
    }
  }
  // Get Posisi

  //End Artikel

  // Perusahaan
  function daftarPerusahaan(){
    $data['perusahaan'] = $this->m_perusahaan->daftarPerusahaan()->result();
    $data['title'] = "Daftar Perusahaan";
    $this->load->view('admin/main/header',$data);
    $this->load->view('admin/perusahaan/daftarPerusahaan');
    $this->load->view('admin/main/footer');
  }
  function tambahPerusahaan(){
    $data['title'] = "Tambah Perusahaan";
    $this->load->view('admin/main/header',$data);
    $this->load->view('admin/perusahaan/tambahPerusahaan');
    $this->load->view('admin/main/footer');
  }
  // End Perusahaan

  // Spesialis
  function daftarKategori(){
    $data['kategori'] = $this->m_kategori->daftarKategori()->result();
    $data['title'] = "Daftar Kategori";
    $this->load->view('admin/main/header',$data);
    $this->load->view('admin/kategori/daftarKategori');
    $this->load->view('admin/main/footer');
  }
  function tambahKategori(){
    $data['title'] = "Tambah Kategori";
    $this->load->view('admin/main/header',$data);
    $this->load->view('admin/kategori/tambahKategori');
    $this->load->view('admin/main/footer');
  }
  // End Spesialis

  // Info Situs
  function infoSitus(){
    $data['title'] = "Info Situs";
    $data['user'] = $this->m_situs->getUser()->result();
    $data['situs'] = $this->m_situs->getSitus()->result();
    $this->load->view('admin/main/header',$data);
    $this->load->view('admin/situs/infoSitus');
    $this->load->view('admin/main/footer');
  }
  // End Info Situs

  // Pages
  function lamanWeb(){
    $data['laman'] = $this->m_laman->getLaman()->result();
    $data['title'] = "Halaman Situs";
    $this->load->view('admin/main/header',$data);
    $this->load->view('admin/laman/lamanWeb');
    $this->load->view('admin/main/footer');
  }

  function iklanSitus(){
    $data['iklan'] = $this->db->query("SELECT * FROM iklan WHERE id=1");
    $data['title'] = "Iklan Situs";
    $this->load->view('admin/main/header',$data);
    $this->load->view('admin/iklan/iklanSitus');
    $this->load->view('admin/main/footer');
  }
  // End Pages
}
