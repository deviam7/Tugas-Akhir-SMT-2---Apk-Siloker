<?php
defined('BASEPATH') or exit('No direct script access allowed');

class laman extends CI_Controller{

  function __construct(){
    parent::__construct();
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }
    $this->load->model('admin/m_laman', 'm_laman');
  }

  public function tambahLaman(){
    $judul  = $this->input->post('judul');
    $isi    = $this->input->post('isiLaman');

    $cekLaman = $this->db->query("SELECT judul_page FROM pages WHERE judul_page='$judul'")->num_rows();
    if ($cekLaman < 1) {
      // Buat Array
      $data = array('judul_page' => $judul, 'isi_page' => $isi, 'tanggal' => date("Y-m-d"));
      $this->m_laman->tambahLaman($data);
      echo "<script>alert('Laman berhasil Diterbitkan')</script>";
      redirect("admin/tampil/lamanWeb","refresh");
    }else {
      echo "<script>alert('Laman Sudah Ada')</script>";
      redirect("admin/tampil/lamanWeb","refresh");
    }
  }

  public function hapusLaman($id){
    $this->db->query("DELETE FROM pages WHERE id='$id'");
    redirect('admin/tampil/lamanWeb','refresh');
  }

  public function editLaman($id){
    $data = $this->m_laman->editLaman($id)->row();
    echo json_encode($data);
  }

  public function updateLaman(){
    $id     = $this->input->post('idLamanEdit');
    $judul  = $this->input->post('judulEdit');
    $isi    = $this->input->post('isiLamanEdit');
    // Buat Array
    $data = array('judul_page' => $judul, 'isi_page' => $isi, "tanggal" => date("Y-m-d"));
    // Kirim DB
    $this->m_laman->updateLaman($data,$id);
    redirect('admin/tampil/lamanWeb','refresh');
  }
}
