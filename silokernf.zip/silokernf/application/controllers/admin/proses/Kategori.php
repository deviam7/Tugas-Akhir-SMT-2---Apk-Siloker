<?php
defined('BASEPATH') or exit("No direct script access allowed");

class kategori extends CI_Controller{

  function __construct(){
    parent::__construct();
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }
  }

  function tambahKategori(){
    $kategori = $this->input->post('namaKategori');
    $kirim = $this->db->query("INSERT INTO kategori set kategori='$kategori'");
    echo "<script>alert('Kategori berhasil di tambahkan')</script>";
    redirect('admin/tampil/daftarKategori','refresh');
  }
  function hapusKategori($id){
    // Cek Kategori Sudah Digunakan atau Belum
    $cek = $this->db->query("SELECT * FROM ket_artikel WHERE id_kategori='$id'");
    if ($cek->num_rows() < 1) {
      $this->db->query("DELETE FROM kategori WHERE id_kategori='$id'");
      echo "<script>alert('Kategori berhasil di hapus')</script>";
      redirect('admin/tampil/daftarKategori','refresh');
    }else {
      echo "<script>alert('Kategori Tersebut Sudah Digunakan, Tidak Bisa Dihapus')</script>";
      redirect('admin/tampil/daftarKategori','refresh');
    }
  }
  public function updateKategori($id,$kategori){
    $this->db->query("UPDATE kategori SET kategori='$kategori' WHERE id_kategori='$id'");
    echo "<script>alert('Kategori berhasil di perbarui')</script>";
    redirect('admin/tampil/daftarKategori','refresh');
  }
}
