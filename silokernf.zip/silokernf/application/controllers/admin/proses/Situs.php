<?php
defined('BASEPATH') or exit("No direct script access allowed");

class situs extends CI_Controller{

  function __construct(){
    parent::__construct();
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }
    $this->load->model('admin/m_situs',"m_situs");
  }


  function updateSitus(){
    $namaSitus = $this->input->post("namaSitus");
    $slogan = $this->input->post("slogan");
    $deskripsi = $this->input->post("deskripsi");
    $email = $this->input->post("email");
    $id   = 1;
    // Cek Gambar Baru
    if ($_FILES['gambar']['name']) {
      // echo "hai";
      $cek  = $this->db->query("SELECT logo FROM info_situs WHERE id=1")->row();
      $cek  = $cek->logo;
      unlink('./assets/gambar/'.$cek);

      $config['upload_path']    = "./assets/gambar/";
      $config['allowed_types']  = "jpg|png|jpeg|gif";
      $config['max_size']       = '10000';
      $config['remove_space']   = TRUE;
      $namaFile                 = $_FILES['gambar']['name'];
      $ekstensi                 = pathinfo($namaFile,PATHINFO_EXTENSION);
      $config['file_name']      = "logo.".$ekstensi;
      $this->load->library('upload',$config);
      $this->upload->do_upload('gambar');
      // Variabel For DB
      $gambar       = $this->upload->data();
      // array db
      $data = array('nama_situs' => $namaSitus, 'slogan' => $slogan, 'deskripsi'=>$deskripsi, 'logo' => $config['file_name'],'email' => $email);
      // Kirim DB
      $kirim = $this->m_situs->updateSitus($data,1);
      if($kirim < 1){
        echo "<script>alert('Logo Gagal Di Upload')</script>";
        redirect("admin/tampil/infoSitus","refresh");
      }else{
        echo "<script>alert('Berhasil Update Situs dengan logo')</script>";
        redirect("admin/tampil/infoSitus","refresh"); 
      }
    }else {
      $data = array('nama_situs' => $namaSitus, 'slogan' => $slogan, 'deskripsi'=>$deskripsi, 'email' => $email);
      // Kirim DB
      $kirim = $this->m_situs->updateSitus($data,0);
      if($kirim < 1){
        echo "<script>alert('Informasi Situs Berhasil Diperbarui')</script>";
        redirect("admin/tampil/infoSitus","refresh");
      }else{
        echo "<script>alert('Gagal')</script>";
        redirect("admin/tampil/infoSitus","refresh"); 
      }
    }
  }

  function tambahUser(){
    $nama   = $this->input->post("nama");
    $email  = $this->input->post("email");
    $user   = $this->input->post("user");
    $pass   = md5($this->input->post("pass"));
    // Cek User Sudah Digunakan Atau Belum
    $cek  = $this->db->query("SELECT * FROM user WHERE user='$user'")->num_rows();
    $cek2 = $this->db->query("SELECT * FROM user WHERE email='$email'")->num_rows();
    if ($cek < 1 AND $cek2 < 1) {
      $data = array('email' => $email, 'nama'=> $nama, 'user' => $user, 'pass' => $pass, 'level' => 1, 'tgl_masuk' => date('Y-m-d'),' status' => 1);
      $this->m_situs->tambahUser($data);
      redirect("admin/tampil/infoSitus","refresh");
    }else {
      echo "<script>alert('User/Password Sudah Digunakan')</script>";
      redirect("admin/tampil/infoSitus","refresh");
    }
  }

  function nonaktifUser($id){
    $this->m_situs->nonaktifUser($id);
    redirect("admin/tampil/infoSitus","refresh");
  }

  public function aktifUser($id){
    $this->m_situs->aktifUser($id);
    redirect("admin/tampil/infoSitus","refresh");
  }
  function editUser($id){
    $data = $this->m_situs->editSitus($id)->row();
    echo json_encode($data);
  }
  function updateUser(){
    $id     = $this->input->post('idUser');
    $nama   = $this->input->post("namaEdit");
    $email  = $this->input->post("emailEdit");
    $pass   = $this->input->post("passEdit");
    // Percabangan Update Password
    if ($pass == null) {
      $data = array('email' => $email, 'nama' =>$nama);
      $this->m_situs->updateUser($data,$id,1);
      redirect("admin/tampil/infoSitus","refresh");
    }else {
      $data = array('email' => $email, 'nama' =>$nama, 'pass' => md5($pass));
      $this->m_situs->updateUser($data,$id,0);
      redirect("admin/tampil/infoSitus","refresh");
    }
  }
}
