<?php
defined('BASEPATH') or exit('No direct script access allowed');

class jabatan extends CI_Controller{

  function __construct(){
    parent::__construct();
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }
    $this->load->model("admin/m_jabatan",'m_jabatan');
  }

  function tambahJabatan(){
    $spesialis  = $this->input->post("namaSpesialis");
    $jabatan    = $this->input->post("namaJabatan");
    // Cek id Spesialis
    $cek = $this->db->query("SELECT * FROM spesialis WHERE id_spesialis='$spesialis'");
    if ($cek->num_rows()< 1) {
      echo "<script>alert('Spesialis Tidak Bisa Ditemukan')</script>";
      redirect('admin/tampil/tambahJabatan','refresh');
    }else {
      // Buat Array
      $data = array('id_spesialis' => $spesialis, 'jabatan' => $jabatan );
      // kirim db
      $kirim = $this->m_jabatan->tambahJabatan($data);
      redirect("admin/tampil/daftarJabatan",'refresh');
    }
  }

  function hapusJabatan($id){
    $cek = $this->db->query("SELECT * FROM ket_artikel WHERE id_jabatan='$id'");
    if ($cek->num_rows() < 1) {
      $this->db->query("DELETE FROM jabatan WHERE id_jabatan='$id'");
      redirect('admin/tampil/daftarJabatan','refresh');
    }else {
      echo "<script>alert('Jabatan Tersebut Sudah Digunakan, Tidak Bisa Dihapus')</script>";
      redirect('admin/tampil/daftarJabatan','refresh');
    }
  }

  function updateJabatan($id,$jabatan){
    $this->db->query("UPDATE jabatan SET jabatan='$jabatan' WHERE id_jabatan='$id'");
    redirect('admin/tampil/daftarJabatan','refresh');
  }
}
