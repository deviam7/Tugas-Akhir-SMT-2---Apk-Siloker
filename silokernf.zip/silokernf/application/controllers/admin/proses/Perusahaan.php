<?php
defined('BASEPATH') or exit("No direct script access allowed");

class perusahaan extends CI_Controller{

  function __construct(){
    parent::__construct();
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }
    $this->load->model('admin/m_perusahaan',"m_perusahaan");
  }

  function tambahPerusahaan(){
    // Config Image
    $config['upload_path']    = "./assets/gambar/perusahaan/";
    $config['allowed_types']  = "jpg|png|jpeg";
    $config['max_size']       = '10000';
    $config['remove_space']   = TRUE;
    $this->load->library('upload',$config);
    if ($this->upload->do_upload('gambar')) {
      $gambar         = $this->upload->data();
      $nama           = $this->input->post('namaPerusahaan');
      $kuantitas      = $this->input->post('kuantitasPekerja');
      $deskripsi      = $this->input->post('deskripsiPerusahaan');
      $urlPerusahaan  = $this->input->post('urlPerusahaan');
      $industri       = $this->input->post('industri');
      $gambar         = $gambar['file_name'];
      // Cek Perusahaan Sudah ada Atau Belum
      $cek = $this->db->query("SELECT * FROM info_perusahaan WHERE nama_perusahaan='$nama'");
      if ($cek->num_rows() < 1) {
        $data = array('nama_perusahaan' => $nama, 'deskripsi_perusahaan' => $deskripsi, 'gambar'=>$gambar, 'url_perusahaan' => $urlPerusahaan, 'industri'=>$industri, 'kuantitas_pekerja'=>$kuantitas );
        // Kirim DB
        $kirim = $this->m_perusahaan->tambahPerusahaan($data);
        redirect("admin/tampil/daftarPerusahaan","refresh");
      }else {
        echo "<script>alert('Perusahaan Sudah Ada')</script>";
        redirect("admin/tampil/tambahPerusahaan","refresh");
      }
    }else {
      $return = array('result' => 'failed', 'file' => '', 'error' => $this->upload->display_errors());
      echo $this->upload->display_errors();
    }
  }

  function editPerusahaan($id){
    $data = $this->m_perusahaan->editPerusahaan($id)->row();
    echo json_encode($data);
  }

  function updatePerusahaan(){

    $nama           = $this->input->post('namaPerusahaan');
    $kuantitas      = $this->input->post('kuantitasPekerja');
    $deskripsi      = $this->input->post('deskripsiPerusahaan');
    $urlPerusahaan  = $this->input->post('urlPerusahaan');
    $industri       = $this->input->post('industri');
    $id   = $this->input->post('idPerusahaan');
    // Cek Gambar Baru
    if ($_FILES['gambar']['name']) {
      // Hapus Gambar Sebelumnya
      $cek  = $this->db->query("SELECT gambar FROM info_perusahaan WHERE id_perusahaan='$id'")->row();
      $cek  = $cek->gambar;
      unlink('./assets/gambar/perusahaan/'.$cek);

      $config['upload_path']    = "./assets/gambar/perusahaan/";
      $config['allowed_types']  = "jpg|png|jpeg|gif";
      $config['max_size']       = '10000';
      $config['remove_space']   = TRUE;
      $namaFile                 = $_FILES['gambar']['name'];
      $ekstensi                 = pathinfo($namaFile,PATHINFO_EXTENSION);
      $config['file_name']      = $nama.".".$ekstensi;
      $this->load->library('upload',$config);
      $this->upload->do_upload('gambar');
      $gambar       = $this->upload->data();

      // Array
      $data = array('nama_perusahaan' => $nama, 'deskripsi_perusahaan' => $deskripsi, 'gambar'=>$config['file_name'], 'url_perusahaan' => $urlPerusahaan, 'industri'=>$industri, 'kuantitas_pekerja'=>$kuantitas);
      // Kirim DB
      $kirim = $this->m_perusahaan->updatePerusahaan($id,$data,1);
      redirect("admin/tampil/daftarPerusahaan","refresh");
    }else {
      $data = array('nama_perusahaan' => $nama, 'deskripsi_perusahaan' => $deskripsi, 'url_perusahaan' => $urlPerusahaan, 'industri'=>$industri, 'kuantitas_pekerja'=>$kuantitas);
      $kirim = $this->m_perusahaan->updatePerusahaan($id,$data,0);
      redirect("admin/tampil/daftarPerusahaan","refresh");
    }
  }
  public function hapusPerusahaan($id){
    $cek = $this->db->query("SELECT * FROM ket_artikel WHERE id_perusahaan='$id'");
    if ($cek->num_rows() < 1) {
      $this->db->query("DELETE FROM info_perusahaan WHERE id_perusahaan='$id'");
      redirect('admin/tampil/daftarPerusahaan','refresh');
    }else {
      echo "<script>alert('Perusahaan Tersebut Sudah Digunakan, Tidak Bisa Dihapus')</script>";
      redirect('admin/tampil/daftarPerusahaan','refresh');
    }
  }
}
