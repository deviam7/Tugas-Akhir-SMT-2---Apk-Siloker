<?php
defined('BASEPATH') or exit('No direct script access allowed');

class iklan extends CI_Controller{

  function __construct(){
    parent::__construct();
    $this->load->model("admin/m_iklan",'m_iklan');
  }

  function tambahIklan(){
    $main     = $this->input->post("main");
    $header   = $this->input->post('header');
    $sidebar  = $this->input->post('sidebar');
    $tengah   = $this->input->post('tengah');
    $url      = $this->input->post('url');
    $home     = $this->input->post('home');
    // array
    $data = array('main' => $main, 'sidebar' => $sidebar, 'tengah' => $tengah, 'header' => $header, 'url' =>$url,'home' =>$home);
    // kirim
    $kirim    = $this->m_iklan->tambahIklan($data);
    echo "<script>alert('Kode iklan berhasil disimpan')</script>";
    redirect('admin/tampil/iklanSitus','refresh');
  }
}
