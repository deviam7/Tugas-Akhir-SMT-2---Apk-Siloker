<?php
defined('BASEPATH') or exit('No direct script access allowed');

class artikel extends CI_Controller{

  function __construct(){
    parent::__construct();
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }
    $this->load->model("admin/m_artikel",'m_artikel');
  }

  function tambahArtikel(){
    $judulPekerjaan = $this->input->post('judulPekerjaan');
    $isiArtikel = $this->input->post('isiArtikel');
    // Deskripsi Seo
    $words = str_word_count($isiArtikel, 2);
    $pos = array_keys($words);
    $deskripsiSeo = substr($isiArtikel, 0, $pos[20]) . '...';
    $idPerusahaan = $this->input->post('idPerusahaan');
    $idKategori  = $this->input->post('idKategori');
    $street = $this->input->post('street');
    $waktuKerja  = $this->input->post('waktuKerja');
    $tanggalDibuka  = $this->input->post('tanggalDibuka');
    $tanggalDitutup  = $this->input->post('tanggalDitutup');
    $provinsi  = $this->input->post('provinsi');
    $kabupaten  = $this->input->post('kabupaten');
    // Get Nama Kabupaten
    $namaKabupaten = $this->db->query("SELECT * FROM regencies WHERE id=$kabupaten")->row();
    $namaKabupaten = explode(" ",$namaKabupaten->name);
    $namaKabupaten = strtolower($namaKabupaten[1]);
    $judulSeo       = "Lowongan Kerja ".$judulPekerjaan." di ".Ucfirst($namaKabupaten); // For keyword dan judul seo
    $slug = strtolower($judulSeo);
    $slug = str_replace(" ", "-",$slug);
    $slug = str_replace('/',"",$slug);
     $slug = str_replace('(',"",$slug);
    $slug = str_replace(')',"",$slug);
    $kodePos  = $this->input->post('kodePos');
    $gajiMin  = $this->input->post('gajiMin');
    $gajiMax  = $this->input->post('gajiMax');
    $skills  = $this->input->post('skills');
    $minimumPendidikan  = $this->input->post('minimumPendidikan');
    $pengalamanBekerja  = $this->input->post('pengalamanBekerja');
    $linkMelamar  = $this->input->post('linkMelamar');
    $emailMelamar  = $this->input->post('emailMelamar');
    $emplyoment    = $this->input->post('emplyoment');

    // Generate Id Artikel
    $cek = $this->db->query("SELECT * FROM ket_artikel ORDER BY id_artikel DESC LIMIT 1");
    if ($cek->num_rows() < 1) {
      $idArtikel = 100;
    }else {
      $idArtikel = $cek->row()->id_artikel+1;
    }
    // array
    $data1  = array('id_artikel' => $idArtikel, 'tanggal_posting' => date('Y-m-d'), 'dibuat_oleh' => $this->session->userdata('id_user'), 'diubah_oleh'=>$this->session->userdata('id_user') );
    $data2  = array('id_artikel' => $idArtikel, 'judul_pekerjaan' => $judulPekerjaan, 'judul_seo'=> $judulSeo, 'deskripsi_seo' => $deskripsiSeo, 'keyword_seo' => $judulSeo, 'slug' => $slug, 'deskripsi_pekerjaan'=> $isiArtikel, 'id_perusahaan' => $idPerusahaan, 'id_kategori' => $idKategori,
    'waktu_bekerja' => $waktuKerja, 'emplyoment' => $emplyoment, 'tanggal_dibuka' => $tanggalDibuka, 'tanggal_tutup' => $tanggalDitutup, 'street' => $street, 'kabupaten' => $kabupaten, 'provinsi' => $provinsi, 'kode_pos' =>$kodePos, 'gaji_min' => $gajiMin, 'gaji_max' => $gajiMax,
    'skills' => $skills, 'minimum_pendidikan' => $minimumPendidikan, 'pengalaman_kerja' => $pengalamanBekerja, 'link_lamar' => $linkMelamar, 'email_lamar' => $emailMelamar);
    // Kirim db
    $kirim = $this->m_artikel->tambahArtikel($data1,$data2);
    echo "<script>alert('Lowongan Kerja Berhasil Diterbitkan')</script>";
    redirect('admin/tampil/daftarArtikel','refresh');
  }

  public function hapusArtikel($id){
    $this->db->query("DELETE artikel, ket_artikel FROM artikel INNER JOIN ket_artikel on artikel.id_artikel=ket_artikel.id_artikel WHERE artikel.id_artikel='$id'");
    redirect('admin/tampil/daftarArtikel','refresh');
  }

  public function updateArtikel(){
    $idArtikel = $this->input->post('idArtikel');
    $judulPekerjaan = $this->input->post('judulPekerjaan');
    $isiArtikel = $this->input->post('isiArtikel');
    // Deskripsi Seo
    $words = str_word_count($isiArtikel, 2);
    $pos = array_keys($words);
    $deskripsiSeo = substr($isiArtikel, 0, $pos[20]) . '...';
    $idPerusahaan = $this->input->post('idPerusahaan');
    $idKategori  = $this->input->post('idKategori');
    $waktuKerja  = $this->input->post('waktuKerja');
    $street   = $this->input->post('street');
    $tanggalDibuka  = $this->input->post('tanggalDibuka');
    $tanggalDitutup  = $this->input->post('tanggalDitutup');
    $provinsi  = $this->input->post('provinsi');
    $kabupaten  = $this->input->post('kabupaten');
    // Get Nama Kabupaten
    $namaKabupaten = $this->db->query("SELECT * FROM regencies WHERE id=$kabupaten")->row();
    $namaKabupaten = explode(" ",$namaKabupaten->name);
    $namaKabupaten = strtolower($namaKabupaten[1]);
    $judulSeo       = "Lowongan Kerja ".$judulPekerjaan." di ".Ucfirst($namaKabupaten); // For keyword dan judul seo
    $slug = strtolower($judulSeo);
    $slug = str_replace('/',"",$slug);
    $slug = str_replace('(',"",$slug);
    $slug = str_replace(')',"",$slug);
    $slug = str_replace(" ", "-",$slug);
    $kodePos  = $this->input->post('kodePos');
    $gajiMin  = $this->input->post('gajiMin');
    $gajiMax  = $this->input->post('gajiMax');
    $skills  = $this->input->post('skills');
    $minimumPendidikan  = $this->input->post('minimumPendidikan');
    $pengalamanBekerja  = $this->input->post('pengalamanBekerja');
    $linkMelamar  = $this->input->post('linkMelamar');
    $emailMelamar  = $this->input->post('emailMelamar');
    $emplyoment    = $this->input->post('emplyoment');

    $data  = array('judul_pekerjaan' => $judulPekerjaan, 'judul_seo'=> $judulSeo, 'deskripsi_seo' => $deskripsiSeo, 'keyword_seo' => $judulSeo, 'slug' => $slug, 'deskripsi_pekerjaan'=> $isiArtikel, 'id_perusahaan' => $idPerusahaan, 'id_kategori' => $idKategori,
    'waktu_bekerja' => $waktuKerja, 'emplyoment' => $emplyoment, 'tanggal_dibuka' => $tanggalDibuka, 'tanggal_tutup' => $tanggalDitutup, 'street' => $street, 'kabupaten' => $kabupaten, 'provinsi' => $provinsi, 'kode_pos' =>$kodePos, 'gaji_min' => $gajiMin, 'gaji_max' => $gajiMax,
    'skills' => $skills, 'minimum_pendidikan' => $minimumPendidikan, 'pengalaman_kerja' => $pengalamanBekerja, 'link_lamar' => $linkMelamar, 'email_lamar' => $emailMelamar);
    // Kirim db
    $kirim = $this->m_artikel->updateArtikel($data,$idArtikel);
    echo "<script>alert('Lowongan Kerja Berhasil Diperbarui')</script>";
    redirect('admin/tampil/daftarArtikel','refresh');
  }
}
