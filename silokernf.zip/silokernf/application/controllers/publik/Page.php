<?php
defined('BASEPATH') or exit("No direct script access allowed");

class page extends CI_Controller{

  function __construct(){
  parent::__construct();
    $this->load->model('publik/m_publik','m_publik');
  }

  function index($page){
    $cekPage = str_replace("-"," ",$page);
    $cekPage = $this->m_publik->getPage($cekPage);
    if ($cekPage->num_rows() < 1) {
      $this->load->view('404');
    }else {
      $data['page'] =$cekPage->result();
      foreach ($cekPage->result() as $look) {
        $data['title'] = $look->judul_page." - ".namaSitus();
      }
      $data['deskripsi'] = "Halaman ".$data['title'];
      $this->load->view('publik/main/header',$data);
      $this->load->view("publik/page");
      $this->load->view('publik/main/footer');
    }
  }
}
