<?php
defined('BASEPATH') or exit("No direct script access allowed");

class Login extends CI_Controller
{

  function __construct(){
    parent::__construct();
    $this->load->model('m_login');
    $this->load->library("form_validation");
  }

  function index(){
    $data['title'] = "Silahkan Login";
    $this->load->view('admin/login',$data);
  }
  function auth(){
    $username=htmlspecialchars($this->input->post('username',TRUE),ENT_QUOTES);
    $password=htmlspecialchars($this->input->post('password',TRUE),ENT_QUOTES);

    $cekAdmin=$this->m_login->auth($username,md5($password));

    if($cekAdmin->num_rows() > 0){
      $data=$cekAdmin->row_array();
      $this->session->set_userdata('masuk',TRUE);
      if($data['level']=='1'){ //Akses admin
        $this->session->set_userdata('id_user',$data['id_user']);
        $this->session->set_userdata('email',$data['email']);
        $this->session->set_userdata('nama',$data['nama']);
        $this->session->set_userdata('user',$data['user']);
        $this->session->set_userdata('tgl_masuk',$data['tgl_masuk']);
        $this->session->set_userdata('level',$data['level']);
        redirect('admin/tampil');
      }elseif ($data['level'] == '0') {
        $cekUser = $this->m_login->authUser($username,md5($password));
        if ($cekUser->num_rows() > 0) {
          $this->session->set_userdata('id_user',$data['id_user']);
          $this->session->set_userdata('email',$data['email']);
          $this->session->set_userdata('nama',$data['nama']);
          $this->session->set_userdata('user',$data['user']);
          $this->session->set_userdata('tgl_masuk',$data['tgl_masuk']);
          $this->session->set_userdata('level',$data['level']);
          redirect('admin/tampil');
        }else {
          echo "<script>alert('User Tersebut Dinonaktifkan, harap hubungi admin')</script>";
          redirect("login",'refresh');
        }
      }
    }else {
      echo "<script>alert('User/Password Salah')</script>";
      redirect("login",'refresh');
    }
  }

  function logout(){
    $this->session->sess_destroy();
    redirect('login');
  }
}
