<?php
defined('BASEPATH') or exit("No direct script access allowed");

class job extends CI_Controller{

  function __construct(){
    parent::__construct();
    $this->load->library('pagination');
    $this->load->model('publik/m_publik','m_publik');
  }

  function index(){
    $config['base_url'] = site_url('job/index'); //site url
    $config['total_rows'] = $this->db->count_all('ket_artikel'); //total row
    $config['per_page'] = 10;  //show record per halaman
    $config["uri_segment"] = 3;  // uri parameter
    $choice = $config["total_rows"] / $config["per_page"];
    $config["num_links"] = floor($choice);

    // Membuat Style pagination untuk BootStrap v4
    $config['first_link']       = 'First';
    $config['last_link']        = 'Last';
    $config['next_link']        = 'Next';
    $config['prev_link']        = 'Prev';
    $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-center">';
    $config['full_tag_close']   = '</ul></nav></div>';
    $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
    $config['num_tag_close']    = '</span></li>';
    $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
    $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
    $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
    $config['next_tagl_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
    $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
    $config['prev_tagl_close']  = '</span>Next</li>';
    $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
    $config['first_tagl_close'] = '</span></li>';
    $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
    $config['last_tagl_close']  = '</span></li>';
    $this->pagination->initialize($config);
    $data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
    $data['artikel'] = $this->m_publik->getArtikel($config["per_page"], $data['page']);
    $data['pagination'] = $this->pagination->create_links();
    $data['deskripsi']  = deskripsiSitus();
    $data['title'] = namaSitus()." - ".sloganSitus();
    $this->load->view('publik/main/header',$data);
    $this->load->view('publik/home');
    $this->load->view('publik/main/footer');
  }

  function job($slug,$id){
    $cekPosting = $this->m_publik->getJob($id);
    if ($cekPosting->num_rows() < 1) {
      echo "Tidak Ada";
    }else {
      $data['job'] = $cekPosting->result();
      foreach ($data['job'] as $look) {
        $data['title'] = $look->judul_seo." - ".namaSitus();
        $data['lowonganTerkait'] = $this->m_publik->lowonganTerkait($look->id_kategori);
      }
      $this->load->view("publik/main/header_artikel",$data);
      $this->load->view("publik/artikel");
      $this->load->view("publik/main/footer");
    }
  }

  function search(){
    $data['key'] = ucwords($this->input->get('key'));
    $cekArtikel  = $this->m_publik->search($data['key']);
    if ($cekArtikel->num_rows() < 1) {
      $data['status'] = 0;
      $data['deskripsi'] = $cekArtikel->num_rows()." Lowongan Pekerjaan ".$data['key']." di Indonesia ".date('Y');
      $data['title'] = "Lowongan Pekerjaan ".$data['key']." di Indonesia - ". namaSitus();
      $this->load->view("publik/main/header",$data);
      $this->load->view("publik/artikelCari");
      $this->load->view("publik/main/footer");
    }else {
      // Pagination
      $config['base_url'] = site_url('job/index'); //site url
      $config['per_page'] = 17;  //show record per halaman
      $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
      $config['total_rows'] = $this->m_publik->searchPagination($config['per_page'],$page,$data['key'])->num_rows(); //total row
      $config["uri_segment"] = 2;  // uri parameter
      $choice = $config["total_rows"] / $config["per_page"];
      $config["num_links"] = floor($choice);
      // Membuat Style pagination untuk BootStrap v4
      $config['first_link']       = 'First';
      $config['last_link']        = 'Last';
      $config['next_link']        = 'Next';
      $config['prev_link']        = 'Prev';
      $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-center">';
      $config['full_tag_close']   = '</ul></nav></div>';
      $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
      $config['num_tag_close']    = '</span></li>';
      $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
      $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
      $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
      $config['next_tagl_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
      $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
      $config['prev_tagl_close']  = '</span>Next</li>';
      $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
      $config['first_tagl_close'] = '</span></li>';
      $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
      $config['last_tagl_close']  = '</span></li>';
      // Initialize Pagination
      $this->pagination->initialize($config);
      $data['page'] = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
      $data['artikel'] = $this->m_publik->searchPagination($config["per_page"], $data['page'],$data['key']);
      $data['pagination'] = $this->pagination->create_links();
      // View
      $data['status'] = 1;
      $data['deskripsi'] = $cekArtikel->num_rows()." Lowongan Pekerjaan ".$data['key']." di Indonesia ".date('Y');
      $data['title'] = "Lowongan Pekerjaan ".$data['key']." di Indonesia - ".namaSitus();
      $this->load->view("publik/main/header",$data);
      $this->load->view("publik/artikelCari");
      $this->load->view("publik/main/footer");
    }
  }
}
