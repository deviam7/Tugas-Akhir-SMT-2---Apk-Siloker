<?php
defined('BASEPATH') or exit("No direct script access allowed");

class not_found extends CI_Controller{

  function __construct(){
    parent::__construct();
  }
  function index(){
    $this->load->view("not_found");
  }
}
