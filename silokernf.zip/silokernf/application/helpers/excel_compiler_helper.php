<?php

function breadcumbs(){
  $ci =& get_instance();
  if ($ci->uri->segment(3) ==null) {
    return "";
  }else {
    if (!ctype_lower($ci->uri->segment(3))) {
      $secondBread = $ci->uri->segment(3);
      $secondBread = preg_replace("([A-Z])", " $0",$secondBread);
      $secondBread = explode(' ', $secondBread);
      return '<div class="container row" style="margin-top:1.5rem">
      <nav class="col s12"style="background-color:#3d6fd4;margin-bottom:1rem;border-radius:5px;">
      <div class="nav-wrapper">
      <div class="col s12">
      <a href="'.base_url().'admin/tampil" class="breadcrumb">Lowongan</a>
      <a href="#!" class="breadcrumb" style="cursor:default;">'.ucfirst($secondBread[0])." ".ucfirst($secondBread[1]).'</a>
      </div>
      </div>
      </div>
      </nav>';
    }else {
      return '<div class="container row" style="margin-top:1.5rem">
      <nav class="col s12" style="background-color:#3d6fd4;margin-bottom:1rem;border-radius:5px;">
      <div class="nav-wrapper">
      <div class="col s12">
      <a href="'.base_url().'admin/tampil" class="breadcrumb">Lowongan</a>
      <a href="#!" class="breadcrumb" style="cursor:default;">'.ucfirst($ci->uri->segment(3)).'</a>
      </div>
      </div>
      </div>
      </nav>';
    }
  }
}

function namaSitus(){
  $ci =& get_instance();
  $coreSitus = $ci->db->get('info_situs')->result();
  foreach ($coreSitus as $look) {
    return $look->nama_situs;
  }
}

function sloganSitus(){
  $ci =& get_instance();
  $coreSitus = $ci->db->get('info_situs')->result();
  foreach ($coreSitus as $look) {
    return $look->slogan;
  }
}

function deskripsiSitus(){
  $ci =& get_instance();
  $coreSitus = $ci->db->get('info_situs')->result();
  foreach ($coreSitus as $look) {
    return $look->deskripsi;
  }
}
function logoSitus(){
  $ci =& get_instance();
  $coreSitus = $ci->db->get('info_situs')->result();
  foreach ($coreSitus as $look) {
    return $look->logo;
  }
}
function kredit(){
  return "Made with <i class='fa fa-heart' aria-hidden='true'></i> by Hasif Priyambudi | DolanBae.com";
}
function emailSitus(){
  $ci =& get_instance();
  $coreSitus = $ci->db->get('info_situs')->result();
  foreach ($coreSitus as $look) {
    return $look->email;
  }
}
function pageSitus(){
  $ci =& get_instance();
  $coreSitus = $ci->db->get('pages')->result();
    return $coreSitus;
}
function getLokasi(){
  $ci =& get_instance();
  return $ci->db->query("SELECT a.kabupaten, count(a.kabupaten) as total,b.name FROM ket_artikel a INNER JOIN regencies b ON a.kabupaten=b.id GROUP BY a.kabupaten ORDER BY total DESC LIMIT 7");
}
function getKategori(){
  $ci =& get_instance();
  return $ci->db->query("SELECT a.id_kategori, count(a.id_kategori) as total, b.kategori FROM ket_artikel a INNER JOIN kategori b ON a.id_kategori=b.id_kategori GROUP BY a.id_kategori ORDER BY total DESC");
}
function totalArtikel(){
  $ci =& get_instance();
  return $ci->db->get("ket_artikel")->num_rows();
}
function totalUser(){
  $ci =& get_instance();
  return $ci->db->get("user")->num_rows();
}
function totalPerusahaan(){
  $ci =& get_instance();
  return $ci->db->get("info_perusahaan")->num_rows();
}
function totalKategori(){
  $ci =& get_instance();
  return $ci->db->get("kategori")->num_rows();
}
function kodeMainAdsense(){
  $ci =& get_instance();
  $data = $ci->db->query("SELECT main FROM iklan WHERE id='1'")->row();
  return $data->main;
}
function kodeSidebarAdsense(){
  $ci =& get_instance();
  $data = $ci->db->query("SELECT sidebar FROM iklan WHERE id='1'")->row();
  return $data->sidebar;
}
function kodeTengahAdsense(){
  $ci =& get_instance();
  $data = $ci->db->query("SELECT tengah FROM iklan WHERE id='1'")->row();
  return $data->tengah;
}
function kodeHeaderAdsense(){
  $ci =& get_instance();
  $data = $ci->db->query("SELECT header FROM iklan WHERE id='1'")->row();
  return $data->header;
}
function kodeUrlAdsense(){
  $ci =& get_instance();
  $data = $ci->db->query("SELECT url FROM iklan WHERE id='1'")->row();
  return $data->url;
}
function kodeHomeAdsense(){
  $ci =& get_instance();
  $data = $ci->db->query("SELECT home FROM iklan WHERE id='1'")->row();
  return $data->home;
}
