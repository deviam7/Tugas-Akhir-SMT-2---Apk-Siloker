<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'job';
$route['404_override'] = 'not_found';
$route['translate_uri_dashes'] = FALSE;

// Routes Publik
$route['page/(:any)']   = "publik/page/index/$1";
$route['(:any)/(:num)'] = "job/job/$1/$2";
$route['job'] = 'job/search';


// Sitemap
$route['sitemap-post.xml'] = "sitemap/post";
$route['sitemap-page.xml'] = "sitemap/page";
$route['sitemap-index.xml'] = "sitemap/home";
