<?php
defined('BASEPATH') or exit("No direct script access allowed");

class m_publik extends CI_Model{

  function getArtikel($limit,$page){
    $this->db->select("*");
    $this->db->from("ket_artikel");
    $this->db->join("artikel","ket_artikel.id_artikel=artikel.id_artikel");
    $this->db->join("kategori","ket_artikel.id_kategori=kategori.id_kategori");
    $this->db->join("info_perusahaan","ket_artikel.id_perusahaan=info_perusahaan.id_perusahaan");
    $this->db->join("regencies","ket_artikel.kabupaten=regencies.id");
    $this->db->order_by('ket_artikel.id_artikel',"DESC");
    $this->db->limit($limit,$page);
    return $this->db->get();
  }
  function getPage($judul){
    return $this->db->query("SELECT * FROM pages WHERE judul_page='$judul'");
  }
  function getJob($id){
    $this->db->select("*");
    $this->db->from("ket_artikel");
    $this->db->join("artikel","ket_artikel.id_artikel=artikel.id_artikel");
    $this->db->join("kategori","ket_artikel.id_kategori=kategori.id_kategori");
    $this->db->join("info_perusahaan","ket_artikel.id_perusahaan=info_perusahaan.id_perusahaan");
    $this->db->join("regencies","ket_artikel.kabupaten=regencies.id");
    $this->db->join("provinces","ket_artikel.provinsi=provinces.id");
    $this->db->where("ket_artikel.id_artikel",$id);
    return $this->db->get();
  }
  function lowonganTerkait($kategori){
    $this->db->select("*");
    $this->db->from("ket_artikel");
    $this->db->join("artikel","ket_artikel.id_artikel=artikel.id_artikel");
    $this->db->join("kategori","ket_artikel.id_kategori=kategori.id_kategori");
    $this->db->join("info_perusahaan","ket_artikel.id_perusahaan=info_perusahaan.id_perusahaan");
    $this->db->join("regencies","ket_artikel.kabupaten=regencies.id");
    $this->db->where("ket_artikel.id_kategori",$kategori);
    $this->db->order_by('rand()');
    $this->db->limit(8);
    return $this->db->get();
  }
  function search($key){
    $this->db->select("*");
    $this->db->from("ket_artikel");
    $this->db->join("artikel","ket_artikel.id_artikel=artikel.id_artikel");
    $this->db->join("kategori","ket_artikel.id_kategori=kategori.id_kategori");
    $this->db->join("info_perusahaan","ket_artikel.id_perusahaan=info_perusahaan.id_perusahaan");
    $this->db->join("regencies","ket_artikel.kabupaten=regencies.id");
    $this->db->like("ket_artikel.judul_seo",$key,'both');
    $this->db->or_like("ket_artikel.keyword_seo",$key,'both');
    $this->db->or_like("ket_artikel.judul_pekerjaan",$key,'both');
    $this->db->or_like("ket_artikel.deskripsi_pekerjaan",$key,'both');
    $this->db->or_like("kategori.kategori",$key,'both');
    $this->db->or_like("info_perusahaan.nama_perusahaan",$key,'both');
    $this->db->or_like("regencies.name",$key,'both');
    $this->db->order_by('ket_artikel.id_artikel',"DESC");
    return $this->db->get();
  }

  function searchPagination($limit,$page,$key){
    $this->db->select("*");
    $this->db->from("ket_artikel");
    $this->db->join("artikel","ket_artikel.id_artikel=artikel.id_artikel");
    $this->db->join("kategori","ket_artikel.id_kategori=kategori.id_kategori");
    $this->db->join("info_perusahaan","ket_artikel.id_perusahaan=info_perusahaan.id_perusahaan");
    $this->db->join("regencies","ket_artikel.kabupaten=regencies.id");
    $this->db->like("ket_artikel.judul_seo",$key,'both');
    $this->db->or_like("ket_artikel.keyword_seo",$key,'both');
    $this->db->or_like("ket_artikel.judul_pekerjaan",$key,'both');
    $this->db->or_like("ket_artikel.deskripsi_pekerjaan",$key,'both');
    $this->db->or_like("kategori.kategori",$key,'both');
    $this->db->or_like("info_perusahaan.nama_perusahaan",$key,'both');
    $this->db->or_like("regencies.name",$key,'both');
    $this->db->order_by('ket_artikel.id_artikel',"DESC");
    $this->db->limit($limit,$page);
    return $this->db->get();
  }
}
