<?php

class m_login extends CI_Model{

  function auth($user,$pass){
    return $this->db->query("SELECT * FROM user WHERE user='$user' AND pass='$pass'LIMIT 1");
  }
  function authUser($user,$pass){
    return $this->db->query("SELECT * FROM user WHERE user='$user' AND pass='$pass' AND status='1'");
  }
}
