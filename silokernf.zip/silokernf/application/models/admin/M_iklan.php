<?php
defined('BASEPATH') or exit("No direct script access allowed");

class m_iklan extends CI_Model{

  function tambahIklan($data){
    return $this->db->query("UPDATE iklan SET main=?,sidebar=?,tengah=?,header=?,url=?,home=? WHERE id='1'",$data);
  }
}
