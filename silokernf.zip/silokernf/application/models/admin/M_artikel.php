<?php
defined('BASEPATH') or exit("No direct script access allowed");

class m_artikel extends CI_Model{

  function __construct(){
    parent::__construct();
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }
  }

  function getProvinsi(){
    $this->db->order_by('name_provinces','ASC');
    $provinces= $this->db->get('provinces');
    return $provinces->result_array();
  }
  public function getKabupaten($id){
    $kabupaten="<option>--pilih--</pilih>";

    $this->db->order_by('name','ASC');
    $kab= $this->db->get_where('regencies',array('province_id'=>$id));

    foreach ($kab->result_array() as $data ){
      $kabupaten.= "<option value='$data[id]'>$data[name]</option>";
    }
    return $kabupaten;
  }
  function getKategori(){
    $this->db->order_by('kategori','ASC');
    return $this->db->get('kategori')->result_array();
  }
  function tambahArtikel($data1,$data2){
    $artikel    = $this->db->insert("artikel",$data1);
    $artikel2   = $this->db->insert("ket_artikel",$data2);
    return TRUE;
  }
  function getArtikel(){
    $this->db->select("*");
    $this->db->from("ket_artikel");
    $this->db->join("artikel","ket_artikel.id_artikel=artikel.id_artikel");
    $this->db->join("kategori","ket_artikel.id_kategori=kategori.id_kategori");
    $this->db->join("info_perusahaan","ket_artikel.id_perusahaan=info_perusahaan.id_perusahaan");
    $this->db->order_by('ket_artikel.id_artikel',"DESC");
    return $this->db->get();
  }
  function updateArtikel($data,$id){
    $tanggal  = date("Y-m-d");
    $idUser   = $this->session->userdata('id_user');
    $artikel  = $this->db->query("UPDATE artikel SET tanggal_update='$tanggal', diubah_oleh = '$idUser' WHERE id_artikel='$id'");
    $artikel2 = $this->db->query("UPDATE ket_artikel SET judul_pekerjaan=?,judul_seo=?,deskripsi_seo=?,keyword_seo=?,slug=?,deskripsi_pekerjaan=?,id_perusahaan=?,id_kategori=?,waktu_bekerja=?,emplyoment=?,tanggal_dibuka=?,tanggal_tutup=?,street=?,kabupaten=?,provinsi=?,kode_pos=?,gaji_min=?,gaji_max=?,skills=?,minimum_pendidikan=?,pengalaman_kerja=?,link_lamar=?,email_lamar=? WHERE id_artikel='$id'",$data);
  }
}
