<?php
defined('BASEPATH') or exit("No direct script access allowed");

class m_situs extends CI_Model{

  function __construct(){
    parent::__construct();
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }
  }

  function getSitus(){
    return $this->db->get('info_situs');
  }

  public function updateSitus($data,$status){
    if ($status==1) {
      return $this->db->query("UPDATE info_situs SET nama_situs=?, slogan=?, deskripsi=?, logo=?,email=? WHERE id='1'",$data);
    }else {
      return $this->db->query("UPDATE info_situs SET nama_situs=?, slogan=?, deskripsi=?, email=? WHERE id='1'",$data);
    }
  }
  public function getUser(){
    return $this->db->get("user");
  }
  public function tambahUser($data){
    return $this->db->insert("user",$data);
  }
  public function nonaktifUser($id){
    return $this->db->query("UPDATE user SET status='0' WHERE id_user='$id'");
  }
  public function aktifUser($id){
    return $this->db->query("UPDATE user SET status='1' WHERE id_user='$id'");
  }
  public function editSitus($id){
    return $this->db->query("SELECT * FROM user WHERE id_user='$id'");
  }
  public function updateUser($data,$id,$kondisi){
    if ($kondisi == 0) {
      return $this->db->query("UPDATE user SET email=?,nama=?,pass=? WHERE id_user='$id'",$data);
    }else {
      return $this->db->query("UPDATE user SET email=?,nama=? WHERE id_user='$id'",$data);
    }
  }
}
