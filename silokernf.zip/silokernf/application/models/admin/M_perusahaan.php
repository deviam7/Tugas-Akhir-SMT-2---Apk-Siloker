<?php
defined('BASEPATH') or exit("No direct script access allowed");

class m_perusahaan extends CI_Model{

  function __construct(){
    parent::__construct();
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }
  }

  function tambahPerusahaan($data){
    return $this->db->insert('info_perusahaan',$data);
  }
  function daftarPerusahaan(){
    return $this->db->query("SELECT * FROM info_perusahaan ORDER BY id_perusahaan");
  }
  function editPerusahaan($id){
    return $this->db->query("SELECT * FROM info_perusahaan WHERE id_perusahaan='$id'");
  }
  function updatePerusahaan($id,$data,$status){
    if ($status==1) {
      return $this->db->query("UPDATE info_perusahaan SET nama_perusahaan=?, deskripsi_perusahaan=?, gambar=?, url_perusahaan=?,industri=?,kuantitas_pekerja=? WHERE id_perusahaan='$id'",$data);
    }else {
      return $this->db->query("UPDATE info_perusahaan SET nama_perusahaan=?, deskripsi_perusahaan=?, url_perusahaan=?,industri=?,kuantitas_pekerja=? WHERE id_perusahaan='$id'",$data);
    }
  }
}
