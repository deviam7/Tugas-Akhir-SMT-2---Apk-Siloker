<?php
defined('BASEPATH') or exit("No direct script access allowed");

class m_kategori extends CI_Model{

  function __construct(){
    parent::__construct();
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }
  }

  function daftarKategori(){
    return $this->db->query("SELECT * FROM kategori ORDER BY kategori ASC");
  }
}
