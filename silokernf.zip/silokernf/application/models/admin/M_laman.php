<?php
defined('BASEPATH') or exit("No direct script access allowed");

class m_laman extends CI_Model{

  function __construct(){
    parent::__construct();
    if ($this->session->userdata('masuk') != TRUE AND $this->session->userdata('level') !=1) {
      echo "<script>alert('Anda Tidak Memiliki Akses')</script>";
      redirect("login","refresh");
    }
  }

  function getLaman(){
    return $this->db->get('pages');
  }
  function tambahLaman($data){
    return $this->db->insert('pages',$data);
  }
  function editLaman($id){
    return $this->db->query("SELECT * FROM pages WHERE id='$id'");
  }
  function updateLaman($data,$id){
    return $this->db->query("UPDATE pages SET judul_page=?,isi_page=?, tanggal=? WHERE id='$id'",$data);
  }
}
